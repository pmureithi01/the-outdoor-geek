module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        'forest-green': '#2E5A35',
        'sky-blue': '#4A90E2',
        'earth-brown': '#8B572A',
        'sunset-orange': '#F5A623',
        'mountain-gray': '#9B9B9B',
        'rock-slate': '#4A4A4A',
        'leaf-green': '#7ED321',
        'water-blue': '#50E3C2',
        'sunrise-yellow': '#F8E71C',
        'alert-red': '#D0021B',
        'free-tier': '#9B9B9B',
        'basic-tier': '#4A90E2',
        'premium-tier': '#F5A623',
        'light-gray': '#F8F8F8',
        'border': '#EEEEEE',
      },
      boxShadow: {
        'light': '0 2px 4px rgba(0, 0, 0, 0.1)',
        'medium': '0 4px 8px rgba(0, 0, 0, 0.1)',
        'heavy': '0 8px 16px rgba(0, 0, 0, 0.1)',
      },
      borderRadius: {
        'sm': '4px',
        'md': '8px',
        'lg': '12px',
      },
      fontFamily: {
        'sans': ['Open Sans', 'sans-serif'],
        'heading': ['Montserrat', 'sans-serif'],
        'mono': ['Roboto Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}
