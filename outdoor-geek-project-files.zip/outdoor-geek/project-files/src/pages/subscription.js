import React from 'react';
import Layout from '../components/layout/Layout';
import SubscriptionManagement from '../components/subscription/SubscriptionManagement';

export default function Subscription() {
  return (
    <Layout>
      <SubscriptionManagement />
    </Layout>
  );
}
