import React from 'react';
import Layout from '../components/layout/Layout';
import CategoryPage from '../components/categories/CategoryPage';

export default function Categories() {
  return (
    <Layout>
      <CategoryPage />
    </Layout>
  );
}
