import React from 'react';
import Layout from '../components/layout/Layout';
import AdvertisingSystem from '../components/advertising/AdvertisingSystem';

export default function Advertising() {
  return (
    <Layout>
      <AdvertisingSystem />
    </Layout>
  );
}
