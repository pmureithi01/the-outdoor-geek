import React from 'react';
import Layout from '../components/layout/Layout';
import ArticleEditor from '../components/writer/ArticleEditor';

export default function WriterEditor() {
  return (
    <Layout>
      <ArticleEditor />
    </Layout>
  );
}
