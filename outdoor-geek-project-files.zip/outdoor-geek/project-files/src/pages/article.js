import React from 'react';
import Layout from '../components/layout/Layout';
import ArticlePage from '../components/articles/ArticlePage';

export default function Article() {
  return (
    <Layout>
      <ArticlePage />
    </Layout>
  );
}
