import React from 'react';
import Layout from '../components/layout/Layout';
import UserProfilePage from '../components/user/UserProfilePage';

export default function Profile() {
  return (
    <Layout>
      <UserProfilePage />
    </Layout>
  );
}
