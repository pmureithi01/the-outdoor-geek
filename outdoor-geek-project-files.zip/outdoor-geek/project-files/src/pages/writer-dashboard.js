import React from 'react';
import Layout from '../components/layout/Layout';
import ContentManagement from '../components/writer/ContentManagement';

export default function WriterDashboard() {
  return (
    <Layout>
      <ContentManagement />
    </Layout>
  );
}
