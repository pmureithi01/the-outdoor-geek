import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import CommentSystem from '../components/comments/CommentSystem';

// Mock the useAuth hook
jest.mock('../lib/auth', () => ({
  useAuth: () => ({
    user: {
      id: '123',
      name: 'Test User',
      email: 'test@example.com'
    },
    isAuthenticated: true
  })
}));

describe('CommentSystem Component', () => {
  const mockComments = [
    {
      id: '1',
      author: {
        id: '456',
        name: 'John Doe',
        avatar: null
      },
      content: 'This is a test comment',
      date: 'Apr 25, 2025',
      likes: 5,
      replies: [
        {
          id: '101',
          author: {
            id: '789',
            name: 'Jane Smith',
            avatar: null
          },
          content: 'This is a reply to the test comment',
          date: 'Apr 25, 2025',
          likes: 2
        }
      ]
    }
  ];

  test('renders comment system correctly with existing comments', () => {
    render(<CommentSystem articleId="article123" comments={mockComments} />);
    
    expect(screen.getByText(/comments \(1\)/i)).toBeInTheDocument();
    expect(screen.getByText('This is a test comment')).toBeInTheDocument();
    expect(screen.getByText('This is a reply to the test comment')).toBeInTheDocument();
    expect(screen.getByText('John Doe')).toBeInTheDocument();
    expect(screen.getByText('Jane Smith')).toBeInTheDocument();
  });
  
  test('renders comment form for authenticated users', () => {
    render(<CommentSystem articleId="article123" comments={[]} />);
    
    expect(screen.getByText(/leave a comment/i)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/write your comment here/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /post comment/i })).toBeInTheDocument();
  });
  
  test('shows login message for unauthenticated users', () => {
    // Override the mock to simulate unauthenticated user
    jest.mock('../lib/auth', () => ({
      useAuth: () => ({
        user: null,
        isAuthenticated: false
      })
    }), { virtual: true });
    
    render(<CommentSystem articleId="article123" comments={[]} />);
    
    expect(screen.getByText(/you need to be logged in to post a comment/i)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /login to comment/i })).toBeInTheDocument();
  });
  
  test('handles posting a new comment', async () => {
    render(<CommentSystem articleId="article123" comments={[]} />);
    
    // Type a comment
    fireEvent.change(screen.getByPlaceholderText(/write your comment here/i), {
      target: { value: 'This is a new test comment' }
    });
    
    // Submit the comment
    fireEvent.click(screen.getByRole('button', { name: /post comment/i }));
    
    // Should show posting state
    expect(screen.getByText(/posting/i)).toBeInTheDocument();
    
    // Should add the new comment to the list
    await waitFor(() => {
      expect(screen.getByText('This is a new test comment')).toBeInTheDocument();
    });
  });
  
  test('handles replying to a comment', async () => {
    render(<CommentSystem articleId="article123" comments={mockComments} />);
    
    // Click reply button on the first comment
    fireEvent.click(screen.getAllByText(/reply/i)[0]);
    
    // Reply form should appear
    expect(screen.getByPlaceholderText(/reply to john doe/i)).toBeInTheDocument();
    
    // Type a reply
    fireEvent.change(screen.getByPlaceholderText(/reply to john doe/i), {
      target: { value: 'This is a new test reply' }
    });
    
    // Submit the reply
    fireEvent.click(screen.getByRole('button', { name: /post reply/i }));
    
    // Should show posting state
    expect(screen.getByText(/posting/i)).toBeInTheDocument();
    
    // Should add the new reply to the list
    await waitFor(() => {
      expect(screen.getByText('This is a new test reply')).toBeInTheDocument();
    });
  });
  
  test('handles liking a comment', () => {
    render(<CommentSystem articleId="article123" comments={mockComments} />);
    
    // Get the like button for the first comment
    const likeButton = screen.getAllByRole('button').find(button => 
      button.textContent.includes('5')
    );
    
    // Click the like button
    fireEvent.click(likeButton);
    
    // Like count should increase
    expect(screen.getByText('6')).toBeInTheDocument();
  });
});
