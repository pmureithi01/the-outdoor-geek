import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import SocialMediaIntegration from '../components/social/SocialMediaIntegration';

describe('SocialMediaIntegration Component', () => {
  const mockProps = {
    articleTitle: 'Test Article Title',
    articleUrl: 'https://theoutdoorgeek.com/articles/test-article'
  };

  // Mock window.open
  const originalOpen = window.open;
  beforeEach(() => {
    window.open = jest.fn();
  });
  
  afterEach(() => {
    window.open = originalOpen;
  });

  test('renders social share buttons correctly', () => {
    render(<SocialMediaIntegration {...mockProps} />);
    
    expect(screen.getByText(/share this article/i)).toBeInTheDocument();
    
    // Check if all share buttons are present
    expect(screen.getByLabelText(/share on facebook/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/share on twitter/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/share on linkedin/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/share via email/i)).toBeInTheDocument();
  });
  
  test('renders social media follow links correctly', () => {
    render(<SocialMediaIntegration {...mockProps} />);
    
    expect(screen.getByText(/follow us/i)).toBeInTheDocument();
    
    // Check if all social media links are present
    const links = screen.getAllByRole('link');
    const socialLinks = links.filter(link => 
      link.getAttribute('href').includes('facebook.com') || 
      link.getAttribute('href').includes('twitter.com') || 
      link.getAttribute('href').includes('instagram.com') || 
      link.getAttribute('href').includes('youtube.com')
    );
    
    expect(socialLinks.length).toBe(5); // 4 follow links + 1 "View more on Instagram" link
  });
  
  test('renders Instagram feed preview correctly', () => {
    render(<SocialMediaIntegration {...mockProps} />);
    
    expect(screen.getByText(/instagram feed/i)).toBeInTheDocument();
    expect(screen.getByText(/view more on instagram/i)).toBeInTheDocument();
    
    // Check if all image placeholders are present
    const imagePlaceholders = screen.getAllByText(/image \d/i);
    expect(imagePlaceholders.length).toBe(6);
  });
  
  test('opens share dialog when Facebook share button is clicked', () => {
    render(<SocialMediaIntegration {...mockProps} />);
    
    fireEvent.click(screen.getByLabelText(/share on facebook/i));
    
    expect(window.open).toHaveBeenCalledWith(
      expect.stringContaining('facebook.com/sharer'),
      '_blank',
      'width=600,height=400'
    );
  });
  
  test('opens share dialog when Twitter share button is clicked', () => {
    render(<SocialMediaIntegration {...mockProps} />);
    
    fireEvent.click(screen.getByLabelText(/share on twitter/i));
    
    expect(window.open).toHaveBeenCalledWith(
      expect.stringContaining('twitter.com/intent/tweet'),
      '_blank',
      'width=600,height=400'
    );
  });
  
  test('opens share dialog when LinkedIn share button is clicked', () => {
    render(<SocialMediaIntegration {...mockProps} />);
    
    fireEvent.click(screen.getByLabelText(/share on linkedin/i));
    
    expect(window.open).toHaveBeenCalledWith(
      expect.stringContaining('linkedin.com/sharing'),
      '_blank',
      'width=600,height=400'
    );
  });
});
