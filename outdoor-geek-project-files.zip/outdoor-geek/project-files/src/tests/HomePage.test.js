import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import HomePage from '../components/home/HomePage';

// Mock any necessary components
jest.mock('../components/layout/Header', () => () => <div data-testid="mock-header">Header</div>);
jest.mock('../components/layout/Footer', () => () => <div data-testid="mock-footer">Footer</div>);

describe('HomePage Component', () => {
  test('renders all homepage sections correctly', () => {
    render(<HomePage />);
    
    // Hero section
    expect(screen.getByText(/explore the outdoors with expert guides/i)).toBeInTheDocument();
    expect(screen.getByText(/join our community of outdoor enthusiasts/i)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /subscribe now/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /explore activities/i })).toBeInTheDocument();
    
    // Popular Activities section
    expect(screen.getByText(/popular activities/i)).toBeInTheDocument();
    expect(screen.getByText(/hiking & trekking/i)).toBeInTheDocument();
    expect(screen.getByText(/kayaking & canoeing/i)).toBeInTheDocument();
    expect(screen.getByText(/rock climbing/i)).toBeInTheDocument();
    expect(screen.getByText(/paragliding/i)).toBeInTheDocument();
    
    // Featured Articles section
    expect(screen.getByText(/featured articles/i)).toBeInTheDocument();
    expect(screen.getByText(/essential gear for hiking in all seasons/i)).toBeInTheDocument();
    expect(screen.getByText(/beginner's guide to kayaking/i)).toBeInTheDocument();
    expect(screen.getByText(/top 10 rock climbing destinations/i)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /view all articles/i })).toBeInTheDocument();
    
    // Subscription Plans section
    expect(screen.getByText(/subscription plans/i)).toBeInTheDocument();
    expect(screen.getByText(/free/i)).toBeInTheDocument();
    expect(screen.getByText(/basic/i)).toBeInTheDocument();
    expect(screen.getByText(/premium/i)).toBeInTheDocument();
    expect(screen.getByText(/\$0\/month/i)).toBeInTheDocument();
    expect(screen.getByText(/\$5\.99\/month/i)).toBeInTheDocument();
    expect(screen.getByText(/\$9\.99\/month/i)).toBeInTheDocument();
    
    // Writer CTA section
    expect(screen.getByText(/become a writer/i)).toBeInTheDocument();
    expect(screen.getByText(/share your outdoor expertise/i)).toBeInTheDocument();
    expect(screen.getByText(/writer benefits/i)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /learn more/i })).toBeInTheDocument();
  });
});
