import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import AdvertisingSystem from '../components/advertising/AdvertisingSystem';

describe('AdvertisingSystem Component', () => {
  test('renders advertising dashboard correctly', () => {
    render(<AdvertisingSystem />);
    
    expect(screen.getByText(/advertising management/i)).toBeInTheDocument();
    expect(screen.getByText(/performance overview/i)).toBeInTheDocument();
    expect(screen.getByText(/your advertisements/i)).toBeInTheDocument();
    
    // Check if tabs are displayed
    expect(screen.getByText(/dashboard/i)).toBeInTheDocument();
    expect(screen.getByText(/create ad/i)).toBeInTheDocument();
    expect(screen.getByText(/settings/i)).toBeInTheDocument();
  });
  
  test('displays existing advertisements', () => {
    render(<AdvertisingSystem />);
    
    expect(screen.getByText(/hiking gear promotion/i)).toBeInTheDocument();
    expect(screen.getByText(/camping equipment sale/i)).toBeInTheDocument();
    expect(screen.getByText(/active/i)).toBeInTheDocument();
    expect(screen.getByText(/scheduled/i)).toBeInTheDocument();
  });
  
  test('switches between tabs', () => {
    render(<AdvertisingSystem />);
    
    // Default should be dashboard tab
    expect(screen.getByText(/performance overview/i)).toBeInTheDocument();
    
    // Click create ad tab
    fireEvent.click(screen.getByText(/create ad/i));
    
    // Should show create ad form
    expect(screen.getByText(/create new advertisement/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/advertisement name/i)).toBeInTheDocument();
    
    // Click settings tab
    fireEvent.click(screen.getByText(/settings/i));
    
    // Should show settings
    expect(screen.getByText(/advertising settings/i)).toBeInTheDocument();
    expect(screen.getByText(/ad display preferences/i)).toBeInTheDocument();
    
    // Click back to dashboard tab
    fireEvent.click(screen.getByText(/dashboard/i));
    
    // Should show dashboard again
    expect(screen.getByText(/performance overview/i)).toBeInTheDocument();
  });
  
  test('handles creating a new advertisement', async () => {
    render(<AdvertisingSystem />);
    
    // Click create ad tab
    fireEvent.click(screen.getByText(/create ad/i));
    
    // Fill in the form
    fireEvent.change(screen.getByLabelText(/advertisement name/i), {
      target: { value: 'New Test Ad' }
    });
    
    fireEvent.change(screen.getByLabelText(/advertisement type/i), {
      target: { value: 'banner' }
    });
    
    fireEvent.change(screen.getByLabelText(/advertisement location/i), {
      target: { value: 'homepage' }
    });
    
    fireEvent.change(screen.getByLabelText(/start date/i), {
      target: { value: '2025-05-01' }
    });
    
    fireEvent.change(screen.getByLabelText(/end date/i), {
      target: { value: '2025-05-31' }
    });
    
    fireEvent.change(screen.getByLabelText(/target url/i), {
      target: { value: 'https://example.com' }
    });
    
    // Submit the form
    fireEvent.click(screen.getByRole('button', { name: /create advertisement/i }));
    
    // Should redirect to dashboard and show the new ad
    // Note: In a real test, we would need to mock the form submission and response
  });
});
