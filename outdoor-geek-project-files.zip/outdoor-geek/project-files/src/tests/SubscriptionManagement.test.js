import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import SubscriptionManagement from '../components/subscription/SubscriptionManagement';

// Mock the useAuth hook
jest.mock('../lib/auth', () => ({
  useAuth: () => ({
    user: {
      id: '123',
      name: 'Test User',
      email: 'test@example.com',
      subscription: 'basic'
    },
    updateUserSubscription: jest.fn()
  })
}));

describe('SubscriptionManagement Component', () => {
  test('renders subscription management page correctly', () => {
    render(<SubscriptionManagement />);
    
    expect(screen.getByText(/manage your subscription/i)).toBeInTheDocument();
    expect(screen.getByText(/current plan/i)).toBeInTheDocument();
    expect(screen.getByText(/basic plan/i)).toBeInTheDocument();
    
    // Check if all subscription tiers are displayed
    expect(screen.getByText(/free/i)).toBeInTheDocument();
    expect(screen.getByText(/basic/i)).toBeInTheDocument();
    expect(screen.getByText(/premium/i)).toBeInTheDocument();
  });
  
  test('toggles between monthly and annual billing cycles', () => {
    render(<SubscriptionManagement />);
    
    // Default should be monthly
    expect(screen.getByText(/\$5\.99\/month/i)).toBeInTheDocument();
    
    // Click annual billing
    fireEvent.click(screen.getByText(/annual/i));
    
    // Should show annual pricing
    expect(screen.getByText(/\$59\.99\/year/i)).toBeInTheDocument();
    
    // Click monthly billing again
    fireEvent.click(screen.getByText(/monthly/i));
    
    // Should show monthly pricing again
    expect(screen.getByText(/\$5\.99\/month/i)).toBeInTheDocument();
  });
  
  test('selects different subscription plan', async () => {
    render(<SubscriptionManagement />);
    
    // Current plan should be Basic
    expect(screen.getByText(/basic plan/i)).toBeInTheDocument();
    
    // Click on Premium plan
    const premiumCard = screen.getByText(/premium/i).closest('.subscription-card');
    fireEvent.click(premiumCard);
    
    // Payment form should appear
    await waitFor(() => {
      expect(screen.getByText(/payment information/i)).toBeInTheDocument();
    });
    
    // Form should show premium price
    expect(screen.getByText(/\$9\.99\/month/i)).toBeInTheDocument();
  });
  
  test('processes subscription upgrade', async () => {
    render(<SubscriptionManagement />);
    
    // Click on Premium plan
    const premiumCard = screen.getByText(/premium/i).closest('.subscription-card');
    fireEvent.click(premiumCard);
    
    // Payment form should appear
    await waitFor(() => {
      expect(screen.getByText(/payment information/i)).toBeInTheDocument();
    });
    
    // Fill in payment details
    fireEvent.change(screen.getByPlaceholderText(/john doe/i), {
      target: { value: 'Test User' }
    });
    
    fireEvent.change(screen.getByPlaceholderText(/1234 1234 1234 1234/i), {
      target: { value: '4242424242424242' }
    });
    
    fireEvent.change(screen.getByPlaceholderText(/mm\/yy/i), {
      target: { value: '12/25' }
    });
    
    fireEvent.change(screen.getByPlaceholderText(/cvc/i), {
      target: { value: '123' }
    });
    
    // Submit form
    fireEvent.click(screen.getByText(/subscribe now/i));
    
    // Should show processing state
    expect(screen.getByText(/processing/i)).toBeInTheDocument();
    
    // Should show success message
    await waitFor(() => {
      expect(screen.getByText(/successfully upgraded to premium plan/i)).toBeInTheDocument();
    });
  });
});
