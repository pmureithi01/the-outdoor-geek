import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import ArticleEditor from '../components/writer/ArticleEditor';

// Mock the useAuth hook
jest.mock('../lib/auth', () => ({
  useAuth: () => ({
    user: {
      id: '123',
      name: 'Test Writer',
      email: 'writer@example.com',
      role: 'writer'
    },
    isWriter: true
  })
}));

describe('ArticleEditor Component', () => {
  test('renders article editor correctly for new article', () => {
    render(<ArticleEditor />);
    
    expect(screen.getByText(/create new article/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/article title/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/excerpt/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/category/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/tags/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/featured image/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/article content/i)).toBeInTheDocument();
    expect(screen.getByText(/save draft/i)).toBeInTheDocument();
    expect(screen.getByText(/publish/i)).toBeInTheDocument();
  });
  
  test('renders article editor correctly for editing existing article', () => {
    const mockArticle = {
      title: 'Test Article',
      content: 'This is a test article content',
      excerpt: 'Test excerpt',
      category: 'Hiking',
      tags: ['hiking', 'outdoors'],
      status: 'published'
    };
    
    render(<ArticleEditor article={mockArticle} isEditing={true} />);
    
    expect(screen.getByText(/edit article/i)).toBeInTheDocument();
    expect(screen.getByDisplayValue('Test Article')).toBeInTheDocument();
    expect(screen.getByDisplayValue('Test excerpt')).toBeInTheDocument();
    expect(screen.getByDisplayValue('This is a test article content')).toBeInTheDocument();
  });
  
  test('handles saving draft article', async () => {
    render(<ArticleEditor />);
    
    // Fill in required fields
    fireEvent.change(screen.getByLabelText(/article title/i), {
      target: { value: 'New Test Article' }
    });
    
    fireEvent.change(screen.getByLabelText(/excerpt/i), {
      target: { value: 'This is a test excerpt' }
    });
    
    fireEvent.change(screen.getByLabelText(/article content/i), {
      target: { value: 'This is the content of the test article' }
    });
    
    // Click save draft button
    fireEvent.click(screen.getByText(/save draft/i));
    
    // Should show saving state
    expect(screen.getByText(/saving/i)).toBeInTheDocument();
    
    // Should show success message
    await waitFor(() => {
      expect(screen.getByText(/draft saved successfully/i)).toBeInTheDocument();
    });
  });
  
  test('handles publishing article', async () => {
    render(<ArticleEditor />);
    
    // Fill in required fields
    fireEvent.change(screen.getByLabelText(/article title/i), {
      target: { value: 'New Test Article' }
    });
    
    fireEvent.change(screen.getByLabelText(/excerpt/i), {
      target: { value: 'This is a test excerpt' }
    });
    
    fireEvent.change(screen.getByLabelText(/article content/i), {
      target: { value: 'This is the content of the test article' }
    });
    
    // Click publish button
    fireEvent.click(screen.getByText(/publish/i));
    
    // Should show publishing state
    expect(screen.getByText(/publishing/i)).toBeInTheDocument();
    
    // Should show success message
    await waitFor(() => {
      expect(screen.getByText(/article published successfully/i)).toBeInTheDocument();
    });
  });
  
  test('restricts access to non-writers', () => {
    // Override the mock to simulate non-writer user
    jest.mock('../lib/auth', () => ({
      useAuth: () => ({
        user: {
          id: '123',
          name: 'Test User',
          email: 'user@example.com',
          role: 'user'
        },
        isWriter: false
      })
    }), { virtual: true });
    
    render(<ArticleEditor />);
    
    expect(screen.getByText(/writer access only/i)).toBeInTheDocument();
    expect(screen.queryByLabelText(/article title/i)).not.toBeInTheDocument();
  });
});
