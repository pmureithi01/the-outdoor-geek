import React, { useState } from 'react';
import { useAuth } from '../../lib/auth';
import LoginForm from './LoginForm';
import RegisterForm from './RegisterForm';

const AuthModal = ({ isOpen, onClose, initialView = 'login' }) => {
  const [view, setView] = useState(initialView);
  const { isAuthenticated } = useAuth();
  
  if (!isOpen || isAuthenticated) return null;
  
  const handleSuccess = () => {
    if (onClose) onClose();
  };
  
  return (
    <div className="fixed inset-0 bg-rock-slate bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-heavy p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-forest-green">
            {view === 'login' ? 'Login' : 'Create Account'}
          </h2>
          <button 
            onClick={onClose}
            className="text-mountain-gray hover:text-rock-slate"
          >
            &times;
          </button>
        </div>
        
        {view === 'login' ? (
          <>
            <LoginForm onSuccess={handleSuccess} />
            <p className="text-center mt-4">
              Don't have an account?{' '}
              <button 
                onClick={() => setView('register')}
                className="text-forest-green hover:underline"
              >
                Sign up
              </button>
            </p>
          </>
        ) : (
          <>
            <RegisterForm onSuccess={handleSuccess} />
            <p className="text-center mt-4">
              Already have an account?{' '}
              <button 
                onClick={() => setView('login')}
                className="text-forest-green hover:underline"
              >
                Login
              </button>
            </p>
          </>
        )}
      </div>
    </div>
  );
};

export default AuthModal;
