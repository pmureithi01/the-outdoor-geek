import React, { useState } from 'react';

const AdvertisingSystem = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [ads, setAds] = useState([
    {
      id: '1',
      name: 'Hiking Gear Promotion',
      type: 'banner',
      location: 'homepage',
      status: 'active',
      impressions: 1245,
      clicks: 87,
      ctr: '6.99%',
      startDate: '2025-04-01',
      endDate: '2025-04-30'
    },
    {
      id: '2',
      name: 'Camping Equipment Sale',
      type: 'sidebar',
      location: 'article-pages',
      status: 'scheduled',
      impressions: 0,
      clicks: 0,
      ctr: '0%',
      startDate: '2025-05-01',
      endDate: '2025-05-31'
    }
  ]);
  
  return (
    <div className="py-12">
      <div className="container">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold text-forest-green mb-8">Advertising Management</h1>
          
          {/* Tabs */}
          <div className="border-b border-border mb-6">
            <div className="flex space-x-6">
              <button 
                className={`pb-3 px-1 ${activeTab === 'dashboard' ? 'border-b-2 border-forest-green text-forest-green font-semibold' : 'text-rock-slate'}`}
                onClick={() => setActiveTab('dashboard')}
              >
                Dashboard
              </button>
              <button 
                className={`pb-3 px-1 ${activeTab === 'create' ? 'border-b-2 border-forest-green text-forest-green font-semibold' : 'text-rock-slate'}`}
                onClick={() => setActiveTab('create')}
              >
                Create Ad
              </button>
              <button 
                className={`pb-3 px-1 ${activeTab === 'settings' ? 'border-b-2 border-forest-green text-forest-green font-semibold' : 'text-rock-slate'}`}
                onClick={() => setActiveTab('settings')}
              >
                Settings
              </button>
            </div>
          </div>
          
          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && (
            <>
              {/* Performance Overview */}
              <div className="bg-white shadow-light rounded-lg overflow-hidden mb-8">
                <div className="p-6">
                  <h2 className="text-xl font-bold mb-6">Performance Overview</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div className="bg-light-gray p-4 rounded-lg">
                      <p className="text-mountain-gray mb-1">Total Impressions</p>
                      <p className="text-3xl font-bold">1,245</p>
                    </div>
                    
                    <div className="bg-light-gray p-4 rounded-lg">
                      <p className="text-mountain-gray mb-1">Total Clicks</p>
                      <p className="text-3xl font-bold">87</p>
                    </div>
                    
                    <div className="bg-light-gray p-4 rounded-lg">
                      <p className="text-mountain-gray mb-1">Average CTR</p>
                      <p className="text-3xl font-bold">6.99%</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Active Ads */}
              <div className="bg-white shadow-light rounded-lg overflow-hidden mb-8">
                <div className="p-6">
                  <h2 className="text-xl font-bold mb-6">Your Advertisements</h2>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="bg-light-gray">
                          <th className="text-left py-3 px-4 font-semibold">Name</th>
                          <th className="text-left py-3 px-4 font-semibold">Type</th>
                          <th className="text-left py-3 px-4 font-semibold">Location</th>
                          <th className="text-left py-3 px-4 font-semibold">Status</th>
                          <th className="text-left py-3 px-4 font-semibold">Impressions</th>
                          <th className="text-left py-3 px-4 font-semibold">Clicks</th>
                          <th className="text-left py-3 px-4 font-semibold">CTR</th>
                          <th className="text-left py-3 px-4 font-semibold">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {ads.map((ad) => (
                          <tr key={ad.id} className="border-t border-border">
                            <td className="py-3 px-4 font-medium">{ad.name}</td>
                            <td className="py-3 px-4 capitalize">{ad.type}</td>
                            <td className="py-3 px-4 capitalize">{ad.location.replace('-', ' ')}</td>
                            <td className="py-3 px-4">
                              <span className={`inline-block px-2 py-1 rounded-full text-xs ${
                                ad.status === 'active' 
                                  ? 'bg-leaf-green bg-opacity-10 text-leaf-green' 
                                  : ad.status === 'scheduled'
                                    ? 'bg-sky-blue bg-opacity-10 text-sky-blue'
                                    : 'bg-mountain-gray bg-opacity-10 text-mountain-gray'
                              }`}>
                                {ad.status.charAt(0).toUpperCase() + ad.status.slice(1)}
                              </span>
                            </td>
                            <td className="py-3 px-4">{ad.impressions.toLocaleString()}</td>
                            <td className="py-3 px-4">{ad.clicks.toLocaleString()}</td>
                            <td className="py-3 px-4">{ad.ctr}</td>
                            <td className="py-3 px-4">
                              <div className="flex space-x-2">
                                <button className="text-forest-green hover:underline">
                                  Edit
                                </button>
                                <button className="text-alert-red hover:underline">
                                  Delete
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </>
          )}
          
          {/* Create Ad Tab */}
          {activeTab === 'create' && (
            <div className="bg-white shadow-light rounded-lg overflow-hidden">
              <div className="p-6">
                <h2 className="text-xl font-bold mb-6">Create New Advertisement</h2>
                
                <form className="space-y-6">
                  <div>
                    <label htmlFor="ad-name" className="block text-rock-slate mb-2 font-medium">
                      Advertisement Name
                    </label>
                    <input
                      id="ad-name"
                      type="text"
                      className="form-control"
                      placeholder="Enter a name for your advertisement"
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="ad-type" className="block text-rock-slate mb-2 font-medium">
                        Advertisement Type
                      </label>
                      <select
                        id="ad-type"
                        className="form-control"
                        required
                      >
                        <option value="">Select ad type</option>
                        <option value="banner">Banner Ad</option>
                        <option value="sidebar">Sidebar Ad</option>
                        <option value="in-content">In-Content Ad</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="ad-location" className="block text-rock-slate mb-2 font-medium">
                        Advertisement Location
                      </label>
                      <select
                        id="ad-location"
                        className="form-control"
                        required
                      >
                        <option value="">Select location</option>
                        <option value="homepage">Homepage</option>
                        <option value="category-pages">Category Pages</option>
                        <option value="article-pages">Article Pages</option>
                        <option value="all-pages">All Pages</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="start-date" className="block text-rock-slate mb-2 font-medium">
                        Start Date
                      </label>
                      <input
                        id="start-date"
                        type="date"
                        className="form-control"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="end-date" className="block text-rock-slate mb-2 font-medium">
                        End Date
                      </label>
                      <input
                        id="end-date"
                        type="date"
                        className="form-control"
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="target-url" className="block text-rock-slate mb-2 font-medium">
                      Target URL
                    </label>
                    <input
                      id="target-url"
                      type="url"
                      className="form-control"
                      placeholder="https://example.com"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-rock-slate mb-2 font-medium">
                      Advertisement Image
                    </label>
                    <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
                      <p className="text-mountain-gray mb-2">Drag and drop an image here, or click to select a file</p>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        id="ad-image"
                      />
                      <label htmlFor="ad-image" className="btn btn-secondary inline-block cursor-pointer">
                        Select Image
                      </label>
                      <p className="text-xs text-mountain-gray mt-2">
                        Recommended sizes: Banner (728x90px), Sidebar (300x250px), In-Content (600x200px)
                      </p>
                    </div>
                  </div>
                  
                  <div>
                    <button type="submit" className="btn btn-primary">
                      Create Advertisement
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
          
          {/* Settings Tab */}
          {activeTab === 'settings' && (
            <div className="bg-white shadow-light rounded-lg overflow-hidden">
              <div className="p-6">
                <h2 className="text-xl font-bold mb-6">Advertising Settings</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold mb-3">Ad Display Preferences</h3>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <input type="checkbox" id="show-homepage" className="mr-2" defaultChecked />
                        <label htmlFor="show-homepage">Show ads on homepage</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="show-articles" className="mr-2" defaultChecked />
                        <label htmlFor="show-articles">Show ads on article pages</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="show-categories" className="mr-2" defaultChecked />
                        <label htmlFor="show-categories">Show ads on category pages</label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-border pt-6">
                    <h3 className="font-semibold mb-3">Payment Information</h3>
                    <p className="text-rock-slate mb-4">
                      Update your payment information for advertising services.
                    </p>
                    <button className="btn btn-secondary">
                      Update Payment Information
                    </button>
                  </div>
                  
                  <div className="border-t border-border pt-6">
                    <h3 className="font-semibold mb-3">Advertising Guidelines</h3>
                    <ul className="list-disc pl-5 space-y-1 text-rock-slate">
                      <li>All advertisements must comply with our content guidelines</li>
                      <li>Advertisements must not contain misleading or false information</li>
                      <li>We reserve the right to reject any advertisement that does not meet our standards</li>
                      <li>Payment is required before advertisements go live</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdvertisingSystem;
