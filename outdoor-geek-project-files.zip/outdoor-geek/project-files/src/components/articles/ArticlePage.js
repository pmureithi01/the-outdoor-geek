import React from 'react';
import Link from 'next/link';
import { Calendar, User, MessageCircle, Share2, Bookmark, ThumbsUp } from 'lucide-react';

const ArticlePage = ({ article }) => {
  return (
    <div className="py-12">
      <div className="container">
        <div className="max-w-4xl mx-auto">
          {/* Article Header */}
          <header className="mb-8">
            <div className="flex items-center gap-2 text-mountain-gray mb-4">
              <Link href={`/activities/${article.category.slug}`} className="text-forest-green hover:text-leaf-green">
                {article.category.name}
              </Link>
              <span>•</span>
              <span className="flex items-center">
                <Calendar size={16} className="mr-1" />
                {article.date}
              </span>
            </div>
            
            <h1 className="text-4xl font-bold text-forest-green mb-4">{article.title}</h1>
            
            <p className="text-rock-slate text-lg mb-6">{article.excerpt}</p>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-mountain-gray bg-opacity-20 flex items-center justify-center mr-2">
                  <User size={20} className="text-rock-slate" />
                </div>
                <div>
                  <p className="font-medium">{article.author.name}</p>
                  <p className="text-sm text-mountain-gray">{article.author.role}</p>
                </div>
              </div>
              
              <div className="flex gap-2 ml-auto">
                <button className="p-2 rounded-full hover:bg-light-gray">
                  <Share2 size={20} className="text-rock-slate" />
                </button>
                <button className="p-2 rounded-full hover:bg-light-gray">
                  <Bookmark size={20} className="text-rock-slate" />
                </button>
              </div>
            </div>
          </header>
          
          {/* Featured Image */}
          <div className="w-full h-96 bg-mountain-gray bg-opacity-20 flex items-center justify-center mb-8 rounded-lg">
            <p className="text-rock-slate font-medium">Featured Image Placeholder</p>
          </div>
          
          {/* Article Content */}
          <div className="prose prose-lg max-w-none mb-12">
            {/* This would be the actual article content */}
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris. Vivamus hendrerit arcu sed erat molestie vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor. Ut in nulla enim. Phasellus molestie magna non est bibendum non venenatis nisl tempor.</p>
            
            <h2>Section Heading</h2>
            
            <p>Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra.</p>
            
            <blockquote>
              <p>This is a blockquote. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus magna. Cras in mi at felis aliquet congue.</p>
            </blockquote>
            
            <p>Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra.</p>
          </div>
          
          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-8">
            {article.tags.map((tag, index) => (
              <Link 
                key={index} 
                href={`/tags/${tag}`} 
                className="bg-light-gray px-3 py-1 rounded-full text-sm text-rock-slate hover:bg-forest-green hover:text-white"
              >
                {tag}
              </Link>
            ))}
          </div>
          
          {/* Article Actions */}
          <div className="flex items-center justify-between border-t border-b border-border py-4 mb-8">
            <div className="flex items-center gap-2">
              <button className="flex items-center gap-1 text-rock-slate hover:text-forest-green">
                <ThumbsUp size={20} />
                <span>{article.likes}</span>
              </button>
              <button className="flex items-center gap-1 text-rock-slate hover:text-forest-green">
                <MessageCircle size={20} />
                <span>{article.comments.length}</span>
              </button>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-sm text-mountain-gray">Share:</span>
              <button className="p-2 rounded-full hover:bg-light-gray">
                <Share2 size={18} className="text-rock-slate" />
              </button>
            </div>
          </div>
          
          {/* Author Bio */}
          <div className="bg-light-gray p-6 rounded-lg mb-12">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-mountain-gray bg-opacity-40 flex items-center justify-center">
                <User size={32} className="text-rock-slate" />
              </div>
              
              <div>
                <h3 className="text-xl font-semibold mb-1">{article.author.name}</h3>
                <p className="text-mountain-gray mb-2">{article.author.role}</p>
                <p className="text-rock-slate">{article.author.bio}</p>
              </div>
            </div>
          </div>
          
          {/* Comments Section */}
          <div>
            <h3 className="text-2xl font-bold mb-6">Comments ({article.comments.length})</h3>
            
            {/* Comment Form */}
            <div className="bg-light-gray p-6 rounded-lg mb-8">
              <h4 className="text-lg font-semibold mb-4">Leave a Comment</h4>
              <form>
                <textarea 
                  className="form-control mb-4" 
                  rows="4" 
                  placeholder="Write your comment here..."
                ></textarea>
                <button type="submit" className="btn btn-primary">
                  Post Comment
                </button>
              </form>
            </div>
            
            {/* Comments List */}
            <div className="space-y-6">
              {article.comments.map((comment, index) => (
                <div key={index} className="border-b border-border pb-6 last:border-0">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-mountain-gray bg-opacity-20 flex items-center justify-center flex-shrink-0">
                      <User size={20} className="text-rock-slate" />
                    </div>
                    
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h5 className="font-semibold">{comment.author}</h5>
                        <span className="text-sm text-mountain-gray">{comment.date}</span>
                      </div>
                      
                      <p className="text-rock-slate mb-2">{comment.content}</p>
                      
                      <div className="flex items-center gap-4">
                        <button className="text-sm text-mountain-gray hover:text-forest-green">Reply</button>
                        <button className="flex items-center gap-1 text-sm text-mountain-gray hover:text-forest-green">
                          <ThumbsUp size={14} />
                          <span>{comment.likes}</span>
                        </button>
                      </div>
                      
                      {/* Nested Replies */}
                      {comment.replies && comment.replies.length > 0 && (
                        <div className="mt-4 space-y-4 pl-4 border-l-2 border-border">
                          {comment.replies.map((reply, replyIndex) => (
                            <div key={replyIndex} className="flex items-start gap-3">
                              <div className="w-8 h-8 rounded-full bg-mountain-gray bg-opacity-20 flex items-center justify-center flex-shrink-0">
                                <User size={16} className="text-rock-slate" />
                              </div>
                              
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <h6 className="font-semibold">{reply.author}</h6>
                                  <span className="text-xs text-mountain-gray">{reply.date}</span>
                                </div>
                                
                                <p className="text-rock-slate text-sm">{reply.content}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticlePage;
