import React from 'react';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="bg-light-gray py-16 md:py-24">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-forest-green mb-4">
              Explore the Outdoors with Expert Guides
            </h1>
            <p className="text-rock-slate text-lg mb-6">
              Join our community of outdoor enthusiasts and discover new adventures, expert tips, and the best gear for your next expedition.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/subscribe" className="btn btn-cta">
                Subscribe Now
              </Link>
              <Link href="/activities" className="btn btn-secondary">
                Explore Activities
              </Link>
            </div>
          </div>
          <div className="relative h-64 md:h-96 rounded-lg overflow-hidden">
            {/* Placeholder for hero image */}
            <div className="absolute inset-0 bg-forest-green bg-opacity-20 flex items-center justify-center">
              <p className="text-white text-xl font-bold">Hero Image Placeholder</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const FeaturedCategories = () => {
  const categories = [
    { name: 'Hiking & Trekking', link: '/activities/land-based/hiking' },
    { name: 'Kayaking & Canoeing', link: '/activities/water-based/kayaking' },
    { name: 'Rock Climbing', link: '/activities/land-based/rock-climbing' },
    { name: 'Paragliding', link: '/activities/air-based/paragliding' },
  ];

  return (
    <section className="py-16">
      <div className="container">
        <h2 className="text-3xl font-bold text-forest-green mb-8">Popular Activities</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, index) => (
            <div key={index} className="card category-card">
              <div className="h-40 bg-mountain-gray bg-opacity-20 flex items-center justify-center mb-4">
                <p className="text-rock-slate font-medium">Image Placeholder</p>
              </div>
              <h3 className="text-xl font-semibold mb-2">{category.name}</h3>
              <Link href={category.link} className="flex items-center text-forest-green hover:text-leaf-green">
                Explore <ArrowRight size={16} className="ml-1" />
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const FeaturedArticles = () => {
  const articles = [
    {
      title: 'Essential Gear for Hiking in All Seasons',
      excerpt: 'Discover the must-have equipment for hiking year-round, from summer heat to winter snow.',
      category: 'Hiking',
      link: '/articles/essential-gear-hiking'
    },
    {
      title: 'Beginner\'s Guide to Kayaking',
      excerpt: 'Everything you need to know to get started with kayaking, from choosing the right kayak to basic techniques.',
      category: 'Kayaking',
      link: '/articles/beginners-guide-kayaking'
    },
    {
      title: 'Top 10 Rock Climbing Destinations',
      excerpt: 'Explore the world\'s most breathtaking climbing spots, from limestone cliffs to granite walls.',
      category: 'Rock Climbing',
      link: '/articles/top-rock-climbing-destinations'
    }
  ];

  return (
    <section className="py-16 bg-light-gray">
      <div className="container">
        <h2 className="text-3xl font-bold text-forest-green mb-8">Featured Articles</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {articles.map((article, index) => (
            <div key={index} className="card content-card">
              <div className="h-48 bg-mountain-gray bg-opacity-20 flex items-center justify-center mb-4">
                <p className="text-rock-slate font-medium">Image Placeholder</p>
              </div>
              <span className="inline-block bg-forest-green text-white text-sm px-3 py-1 rounded-full mb-2">
                {article.category}
              </span>
              <h3 className="text-xl font-semibold mb-2">{article.title}</h3>
              <p className="text-rock-slate mb-4">{article.excerpt}</p>
              <Link href={article.link} className="flex items-center text-forest-green hover:text-leaf-green">
                Read More <ArrowRight size={16} className="ml-1" />
              </Link>
            </div>
          ))}
        </div>
        <div className="text-center mt-8">
          <Link href="/articles" className="btn btn-secondary">
            View All Articles
          </Link>
        </div>
      </div>
    </section>
  );
};

const SubscriptionPlans = () => {
  const plans = [
    {
      name: 'Free',
      price: '$0',
      features: [
        'Access to 5 articles per month',
        'Basic commenting functionality',
        'Newsletter subscription',
        'Account creation'
      ],
      buttonText: 'Sign Up Free',
      buttonLink: '/subscribe/free',
      highlighted: false
    },
    {
      name: 'Basic',
      price: '$5.99',
      annualPrice: '$59.99',
      annualSaving: 'Save 16%',
      features: [
        'Unlimited article access',
        'Ad-reduced experience',
        'Enhanced commenting features',
        'Access to basic guides and tutorials',
        'Discounted annual subscription option'
      ],
      buttonText: 'Subscribe Now',
      buttonLink: '/subscribe/basic',
      highlighted: true
    },
    {
      name: 'Premium',
      price: '$9.99',
      annualPrice: '$99.99',
      annualSaving: 'Save 16%',
      features: [
        'All Basic tier features',
        'Ad-free experience',
        'Exclusive content access',
        'Early access to new content',
        'Downloadable resources',
        'Priority support',
        'Writer/contributor features'
      ],
      buttonText: 'Go Premium',
      buttonLink: '/subscribe/premium',
      highlighted: false
    }
  ];

  return (
    <section className="py-16">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-forest-green mb-4">Subscription Plans</h2>
          <p className="text-rock-slate text-lg max-w-2xl mx-auto">
            Choose the plan that works best for you and get access to exclusive content, features, and benefits.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`subscription-card ${plan.name.toLowerCase()} ${plan.highlighted ? 'transform scale-105 shadow-heavy' : ''}`}
            >
              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <div className="mb-6">
                <span className="text-3xl font-bold">{plan.price}</span>
                <span className="text-mountain-gray">/month</span>
                {plan.annualPrice && (
                  <div className="mt-2">
                    <span className="text-mountain-gray">Annual: </span>
                    <span className="font-semibold">{plan.annualPrice}</span>
                    <span className="ml-2 text-sm bg-sunset-orange text-white px-2 py-1 rounded-full">
                      {plan.annualSaving}
                    </span>
                  </div>
                )}
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <span className="text-leaf-green mr-2">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <Link 
                href={plan.buttonLink} 
                className={`btn w-full ${plan.highlighted ? 'btn-cta' : 'btn-primary'}`}
              >
                {plan.buttonText}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const WriterCTA = () => {
  return (
    <section className="py-16 bg-forest-green text-white">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">Become a Writer</h2>
            <p className="mb-6">
              Share your outdoor expertise, promote your affiliate links, and connect with a community of outdoor enthusiasts.
            </p>
            <Link href="/writers" className="btn bg-white text-forest-green hover:bg-opacity-90">
              Learn More
            </Link>
          </div>
          <div className="bg-white bg-opacity-10 p-8 rounded-lg">
            <h3 className="text-xl font-semibold mb-4">Writer Benefits</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-sunrise-yellow mr-2">✓</span>
                <span>Personal profile page</span>
              </li>
              <li className="flex items-start">
                <span className="text-sunrise-yellow mr-2">✓</span>
                <span>Content creation tools</span>
              </li>
              <li className="flex items-start">
                <span className="text-sunrise-yellow mr-2">✓</span>
                <span>Ability to include affiliate links</span>
              </li>
              <li className="flex items-start">
                <span className="text-sunrise-yellow mr-2">✓</span>
                <span>Analytics dashboard</span>
              </li>
              <li className="flex items-start">
                <span className="text-sunrise-yellow mr-2">✓</span>
                <span>Revenue sharing based on engagement</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

const HomePage = () => {
  return (
    <div>
      <Hero />
      <FeaturedCategories />
      <FeaturedArticles />
      <SubscriptionPlans />
      <WriterCTA />
    </div>
  );
};

export default HomePage;
