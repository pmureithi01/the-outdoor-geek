import React from 'react';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

const CategoryPage = ({ category, activities }) => {
  return (
    <div className="py-12">
      <div className="container">
        <header className="mb-12">
          <h1 className="text-4xl font-bold text-forest-green mb-4">{category.name}</h1>
          <p className="text-rock-slate text-lg">{category.description}</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {activities.map((activity, index) => (
            <div key={index} className="card category-card">
              <div className="h-48 bg-mountain-gray bg-opacity-20 flex items-center justify-center mb-4">
                <p className="text-rock-slate font-medium">Image Placeholder</p>
              </div>
              <h3 className="text-xl font-semibold mb-2">{activity.name}</h3>
              <p className="text-rock-slate mb-4">{activity.description}</p>
              <Link href={activity.link} className="flex items-center text-forest-green hover:text-leaf-green">
                Explore <ArrowRight size={16} className="ml-1" />
              </Link>
            </div>
          ))}
        </div>

        <div className="bg-light-gray p-8 rounded-lg">
          <h2 className="text-2xl font-bold text-forest-green mb-4">Popular Articles in {category.name}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {category.popularArticles.map((article, index) => (
              <div key={index} className="flex gap-4">
                <div className="w-24 h-24 bg-mountain-gray bg-opacity-20 flex-shrink-0 flex items-center justify-center">
                  <p className="text-rock-slate text-xs">Image</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">{article.title}</h3>
                  <p className="text-rock-slate text-sm mb-2">{article.excerpt}</p>
                  <Link href={article.link} className="text-sm flex items-center text-forest-green hover:text-leaf-green">
                    Read More <ArrowRight size={14} className="ml-1" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;
