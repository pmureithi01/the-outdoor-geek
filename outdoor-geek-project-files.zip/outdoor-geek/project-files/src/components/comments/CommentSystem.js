import React, { useState } from 'react';
import { useAuth } from '../../lib/auth';
import { MessageCircle, ThumbsUp, Flag } from 'lucide-react';

const CommentSystem = ({ articleId, comments: initialComments = [] }) => {
  const { user, isAuthenticated } = useAuth();
  const [comments, setComments] = useState(initialComments);
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState(null);
  const [replyContent, setReplyContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleSubmitComment = (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    
    setIsSubmitting(true);
    
    // Simulate API call to post comment
    setTimeout(() => {
      const comment = {
        id: Date.now().toString(),
        author: {
          id: user.id,
          name: user.name,
          avatar: null
        },
        content: newComment,
        date: new Date().toLocaleDateString(),
        likes: 0,
        replies: []
      };
      
      setComments([...comments, comment]);
      setNewComment('');
      setIsSubmitting(false);
    }, 1000);
  };
  
  const handleSubmitReply = (commentId) => {
    if (!replyContent.trim()) return;
    
    setIsSubmitting(true);
    
    // Simulate API call to post reply
    setTimeout(() => {
      const reply = {
        id: Date.now().toString(),
        author: {
          id: user.id,
          name: user.name,
          avatar: null
        },
        content: replyContent,
        date: new Date().toLocaleDateString(),
        likes: 0
      };
      
      const updatedComments = comments.map(comment => {
        if (comment.id === commentId) {
          return {
            ...comment,
            replies: [...(comment.replies || []), reply]
          };
        }
        return comment;
      });
      
      setComments(updatedComments);
      setReplyContent('');
      setReplyingTo(null);
      setIsSubmitting(false);
    }, 1000);
  };
  
  const handleLikeComment = (commentId) => {
    const updatedComments = comments.map(comment => {
      if (comment.id === commentId) {
        return {
          ...comment,
          likes: comment.likes + 1
        };
      }
      return comment;
    });
    
    setComments(updatedComments);
  };
  
  return (
    <div className="mt-12">
      <h3 className="text-2xl font-bold mb-6">Comments ({comments.length})</h3>
      
      {/* Comment Form */}
      {isAuthenticated ? (
        <div className="bg-light-gray p-6 rounded-lg mb-8">
          <h4 className="text-lg font-semibold mb-4">Leave a Comment</h4>
          <form onSubmit={handleSubmitComment}>
            <textarea 
              className="form-control mb-4" 
              rows="4" 
              placeholder="Write your comment here..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              required
            ></textarea>
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Posting...' : 'Post Comment'}
            </button>
          </form>
        </div>
      ) : (
        <div className="bg-light-gray p-6 rounded-lg mb-8 text-center">
          <p className="mb-4">You need to be logged in to post a comment.</p>
          <a href="/login" className="btn btn-primary">Login to Comment</a>
        </div>
      )}
      
      {/* Comments List */}
      <div className="space-y-6">
        {comments.length > 0 ? (
          comments.map((comment) => (
            <div key={comment.id} className="border-b border-border pb-6 last:border-0">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-mountain-gray bg-opacity-20 flex items-center justify-center flex-shrink-0">
                  {comment.author.avatar ? (
                    <img 
                      src={comment.author.avatar} 
                      alt={comment.author.name} 
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <span className="text-rock-slate font-medium">
                      {comment.author.name.charAt(0).toUpperCase()}
                    </span>
                  )}
                </div>
                
                <div className="flex-grow">
                  <div className="flex items-center gap-2 mb-1">
                    <h5 className="font-semibold">{comment.author.name}</h5>
                    <span className="text-sm text-mountain-gray">{comment.date}</span>
                  </div>
                  
                  <p className="text-rock-slate mb-3">{comment.content}</p>
                  
                  <div className="flex items-center gap-4">
                    {isAuthenticated && (
                      <button 
                        className="text-sm text-mountain-gray hover:text-forest-green"
                        onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}
                      >
                        Reply
                      </button>
                    )}
                    <button 
                      className="flex items-center gap-1 text-sm text-mountain-gray hover:text-forest-green"
                      onClick={() => handleLikeComment(comment.id)}
                    >
                      <ThumbsUp size={14} />
                      <span>{comment.likes}</span>
                    </button>
                    {isAuthenticated && (
                      <button className="flex items-center gap-1 text-sm text-mountain-gray hover:text-alert-red">
                        <Flag size={14} />
                        <span>Report</span>
                      </button>
                    )}
                  </div>
                  
                  {/* Reply Form */}
                  {isAuthenticated && replyingTo === comment.id && (
                    <div className="mt-4">
                      <textarea
                        className="form-control mb-2"
                        rows="2"
                        placeholder={`Reply to ${comment.author.name}...`}
                        value={replyContent}
                        onChange={(e) => setReplyContent(e.target.value)}
                      ></textarea>
                      <div className="flex justify-end space-x-2">
                        <button 
                          className="btn btn-secondary btn-sm"
                          onClick={() => setReplyingTo(null)}
                        >
                          Cancel
                        </button>
                        <button 
                          className="btn btn-primary btn-sm"
                          onClick={() => handleSubmitReply(comment.id)}
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? 'Posting...' : 'Post Reply'}
                        </button>
                      </div>
                    </div>
                  )}
                  
                  {/* Nested Replies */}
                  {comment.replies && comment.replies.length > 0 && (
                    <div className="mt-4 space-y-4 pl-4 border-l-2 border-border">
                      {comment.replies.map((reply) => (
                        <div key={reply.id} className="flex items-start gap-3">
                          <div className="w-8 h-8 rounded-full bg-mountain-gray bg-opacity-20 flex items-center justify-center flex-shrink-0">
                            {reply.author.avatar ? (
                              <img 
                                src={reply.author.avatar} 
                                alt={reply.author.name} 
                                className="w-full h-full rounded-full object-cover"
                              />
                            ) : (
                              <span className="text-rock-slate text-xs font-medium">
                                {reply.author.name.charAt(0).toUpperCase()}
                              </span>
                            )}
                          </div>
                          
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h6 className="font-semibold">{reply.author.name}</h6>
                              <span className="text-xs text-mountain-gray">{reply.date}</span>
                            </div>
                            
                            <p className="text-rock-slate text-sm mb-2">{reply.content}</p>
                            
                            <div className="flex items-center gap-3">
                              <button 
                                className="flex items-center gap-1 text-xs text-mountain-gray hover:text-forest-green"
                              >
                                <ThumbsUp size={12} />
                                <span>{reply.likes}</span>
                              </button>
                              {isAuthenticated && (
                                <button className="flex items-center gap-1 text-xs text-mountain-gray hover:text-alert-red">
                                  <Flag size={12} />
                                  <span>Report</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-mountain-gray">
            <MessageCircle size={32} className="mx-auto mb-2" />
            <p>No comments yet. Be the first to comment!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CommentSystem;
