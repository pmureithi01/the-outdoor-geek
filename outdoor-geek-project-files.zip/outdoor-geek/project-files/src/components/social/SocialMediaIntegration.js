import React from 'react';
import { Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const SocialMediaIntegration = ({ articleTitle, articleUrl }) => {
  // Generate share URLs
  const facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(articleUrl)}`;
  const twitterShareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(articleTitle)}&url=${encodeURIComponent(articleUrl)}`;
  const linkedinShareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(articleUrl)}`;
  const emailShareUrl = `mailto:?subject=${encodeURIComponent(articleTitle)}&body=${encodeURIComponent(`Check out this article: ${articleUrl}`)}`;

  // Handle share button clicks
  const handleShareClick = (url) => {
    window.open(url, '_blank', 'width=600,height=400');
  };

  return (
    <div>
      {/* Social Share Buttons */}
      <div className="social-share">
        <h4 className="text-lg font-semibold mb-3">Share This Article</h4>
        <div className="flex space-x-3">
          <button 
            onClick={() => handleShareClick(facebookShareUrl)}
            className="bg-[#3b5998] text-white p-2 rounded-full hover:opacity-90"
            aria-label="Share on Facebook"
          >
            <Facebook size={20} />
          </button>
          <button 
            onClick={() => handleShareClick(twitterShareUrl)}
            className="bg-[#1da1f2] text-white p-2 rounded-full hover:opacity-90"
            aria-label="Share on Twitter"
          >
            <Twitter size={20} />
          </button>
          <button 
            onClick={() => handleShareClick(linkedinShareUrl)}
            className="bg-[#0077b5] text-white p-2 rounded-full hover:opacity-90"
            aria-label="Share on LinkedIn"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
              <rect x="2" y="9" width="4" height="12"></rect>
              <circle cx="4" cy="4" r="2"></circle>
            </svg>
          </button>
          <button 
            onClick={() => window.location.href = emailShareUrl}
            className="bg-[#777] text-white p-2 rounded-full hover:opacity-90"
            aria-label="Share via Email"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
              <polyline points="22,6 12,13 2,6"></polyline>
            </svg>
          </button>
        </div>
      </div>

      {/* Social Media Feed Widget */}
      <div className="social-feed mt-8">
        <h4 className="text-lg font-semibold mb-3">Follow Us</h4>
        <div className="flex space-x-4">
          <a 
            href="https://facebook.com/theoutdoorgeek" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-[#3b5998] hover:opacity-80"
            aria-label="Facebook"
          >
            <Facebook size={24} />
          </a>
          <a 
            href="https://twitter.com/theoutdoorgeek" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-[#1da1f2] hover:opacity-80"
            aria-label="Twitter"
          >
            <Twitter size={24} />
          </a>
          <a 
            href="https://instagram.com/theoutdoorgeek" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-[#e1306c] hover:opacity-80"
            aria-label="Instagram"
          >
            <Instagram size={24} />
          </a>
          <a 
            href="https://youtube.com/theoutdoorgeek" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-[#ff0000] hover:opacity-80"
            aria-label="YouTube"
          >
            <Youtube size={24} />
          </a>
        </div>
      </div>

      {/* Instagram Feed Preview */}
      <div className="instagram-feed mt-8">
        <h4 className="text-lg font-semibold mb-3">Instagram Feed</h4>
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3, 4, 5, 6].map((item) => (
            <div key={item} className="aspect-square bg-light-gray flex items-center justify-center">
              <span className="text-mountain-gray text-sm">Image {item}</span>
            </div>
          ))}
        </div>
        <a 
          href="https://instagram.com/theoutdoorgeek" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-forest-green hover:underline text-sm mt-2 inline-block"
        >
          View more on Instagram
        </a>
      </div>
    </div>
  );
};

export default SocialMediaIntegration;
