import React, { useState } from 'react';
import Link from 'next/link';
import { CreditCard, Check, X } from 'lucide-react';

const SubscriptionPage = () => {
  const [billingCycle, setBillingCycle] = useState('monthly');
  const [selectedPlan, setSelectedPlan] = useState('basic');

  const plans = [
    {
      id: 'free',
      name: 'Free',
      monthlyPrice: '$0',
      annualPrice: '$0',
      features: [
        'Access to 5 articles per month',
        'Basic commenting functionality',
        'Newsletter subscription',
        'Account creation'
      ],
      notIncluded: [
        'Unlimited article access',
        'Ad-free experience',
        'Enhanced commenting features',
        'Access to guides and tutorials',
        'Exclusive content access'
      ]
    },
    {
      id: 'basic',
      name: 'Basic',
      monthlyPrice: '$5.99',
      annualPrice: '$59.99',
      annualSaving: 'Save 16%',
      features: [
        'Unlimited article access',
        'Ad-reduced experience',
        'Enhanced commenting features',
        'Access to basic guides and tutorials',
        'Discounted annual subscription option'
      ],
      notIncluded: [
        'Ad-free experience',
        'Exclusive content access',
        'Early access to new content',
        'Downloadable resources',
        'Priority support'
      ]
    },
    {
      id: 'premium',
      name: 'Premium',
      monthlyPrice: '$9.99',
      annualPrice: '$99.99',
      annualSaving: 'Save 16%',
      features: [
        'All Basic tier features',
        'Ad-free experience',
        'Exclusive content access',
        'Early access to new content',
        'Downloadable resources',
        'Priority support',
        'Writer/contributor features'
      ],
      notIncluded: []
    }
  ];

  return (
    <div className="py-12">
      <div className="container">
        <div className="max-w-5xl mx-auto">
          <header className="text-center mb-12">
            <h1 className="text-4xl font-bold text-forest-green mb-4">Choose Your Subscription Plan</h1>
            <p className="text-rock-slate text-lg max-w-2xl mx-auto">
              Get access to exclusive content, features, and benefits with our subscription plans.
            </p>
          </header>

          {/* Billing Toggle */}
          <div className="flex justify-center mb-12">
            <div className="bg-light-gray inline-flex rounded-lg p-1">
              <button
                className={`px-4 py-2 rounded-md ${billingCycle === 'monthly' ? 'bg-white shadow-sm' : ''}`}
                onClick={() => setBillingCycle('monthly')}
              >
                Monthly
              </button>
              <button
                className={`px-4 py-2 rounded-md ${billingCycle === 'annual' ? 'bg-white shadow-sm' : ''}`}
                onClick={() => setBillingCycle('annual')}
              >
                Annual <span className="text-xs text-sunset-orange font-medium">Save 16%</span>
              </button>
            </div>
          </div>

          {/* Subscription Plans */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className={`subscription-card ${plan.id} ${selectedPlan === plan.id ? 'border-2 border-forest-green' : ''}`}
                onClick={() => setSelectedPlan(plan.id)}
              >
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-2xl font-bold">{plan.name}</h3>
                  {selectedPlan === plan.id && (
                    <span className="bg-forest-green text-white p-1 rounded-full">
                      <Check size={16} />
                    </span>
                  )}
                </div>

                <div className="mb-6">
                  <span className="text-3xl font-bold">
                    {billingCycle === 'monthly' ? plan.monthlyPrice : plan.annualPrice}
                  </span>
                  <span className="text-mountain-gray">
                    {billingCycle === 'monthly' ? '/month' : '/year'}
                  </span>
                  {billingCycle === 'annual' && plan.annualSaving && (
                    <div className="mt-2">
                      <span className="text-sm bg-sunset-orange text-white px-2 py-1 rounded-full">
                        {plan.annualSaving}
                      </span>
                    </div>
                  )}
                </div>

                <div className="mb-6">
                  <h4 className="font-semibold mb-2">What's included:</h4>
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <span className="text-leaf-green mr-2">
                          <Check size={16} />
                        </span>
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {plan.notIncluded && plan.notIncluded.length > 0 && (
                  <div className="mb-6">
                    <h4 className="font-semibold mb-2">Not included:</h4>
                    <ul className="space-y-2">
                      {plan.notIncluded.map((feature, index) => (
                        <li key={index} className="flex items-start text-mountain-gray">
                          <span className="mr-2">
                            <X size={16} />
                          </span>
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <button
                  className={`btn w-full ${
                    selectedPlan === plan.id ? 'btn-cta' : 'btn-secondary'
                  }`}
                >
                  {plan.id === 'free' ? 'Sign Up Free' : 'Select Plan'}
                </button>
              </div>
            ))}
          </div>

          {/* Payment Form */}
          {selectedPlan !== 'free' && (
            <div className="bg-light-gray p-8 rounded-lg">
              <h2 className="text-2xl font-bold mb-6">Payment Information</h2>
              
              <form>
                <div className="mb-6">
                  <label className="block text-rock-slate mb-2">Name on Card</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="John Doe"
                  />
                </div>
                
                <div className="mb-6">
                  <label className="block text-rock-slate mb-2">Card Information</label>
                  <div className="relative">
                    <input
                      type="text"
                      className="form-control pl-10"
                      placeholder="1234 1234 1234 1234"
                    />
                    <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 text-mountain-gray" size={20} />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="MM/YY"
                    />
                    <input
                      type="text"
                      className="form-control"
                      placeholder="CVC"
                    />
                  </div>
                </div>
                
                <div className="mb-6">
                  <label className="block text-rock-slate mb-2">Billing Address</label>
                  <input
                    type="text"
                    className="form-control mb-4"
                    placeholder="Street Address"
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="City"
                    />
                    <input
                      type="text"
                      className="form-control"
                      placeholder="State/Province"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ZIP/Postal Code"
                    />
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Country"
                    />
                  </div>
                </div>
                
                <div className="mb-6">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span className="text-sm text-rock-slate">
                      I agree to the <Link href="/terms" className="text-forest-green hover:underline">Terms of Service</Link> and <Link href="/privacy" className="text-forest-green hover:underline">Privacy Policy</Link>
                    </span>
                  </label>
                </div>
                
                <button type="submit" className="btn btn-cta w-full">
                  Subscribe Now - {billingCycle === 'monthly' 
                    ? plans.find(p => p.id === selectedPlan).monthlyPrice + '/month' 
                    : plans.find(p => p.id === selectedPlan).annualPrice + '/year'}
                </button>
                
                <p className="text-sm text-mountain-gray text-center mt-4">
                  You can cancel your subscription at any time from your account settings.
                </p>
              </form>
            </div>
          )}

          {/* FAQ Section */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-forest-green mb-6">Frequently Asked Questions</h2>
            
            <div className="space-y-4">
              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold mb-2">Can I change my plan later?</h3>
                <p className="text-rock-slate">Yes, you can upgrade or downgrade your plan at any time from your account settings.</p>
              </div>
              
              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold mb-2">How do I cancel my subscription?</h3>
                <p className="text-rock-slate">You can cancel your subscription at any time from your account settings. Your subscription will remain active until the end of your current billing period.</p>
              </div>
              
              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold mb-2">What payment methods do you accept?</h3>
                <p className="text-rock-slate">We accept all major credit cards, including Visa, Mastercard, American Express, and Discover.</p>
              </div>
              
              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold mb-2">Is there a refund policy?</h3>
                <p className="text-rock-slate">We offer a 14-day money-back guarantee if you're not satisfied with your subscription.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionPage;
