import React, { useState } from 'react';
import { useAuth } from '../../lib/auth';

const SubscriptionManagement = () => {
  const { user, updateUserSubscription } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState(user?.subscription || 'free');
  const [billingCycle, setBillingCycle] = useState('monthly');
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('stripe');
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const plans = [
    {
      id: 'free',
      name: 'Free',
      monthlyPrice: '$0',
      annualPrice: '$0',
      features: [
        'Access to 5 articles per month',
        'Basic commenting functionality',
        'Newsletter subscription',
        'Account creation'
      ]
    },
    {
      id: 'basic',
      name: 'Basic',
      monthlyPrice: '$5.99',
      annualPrice: '$59.99',
      annualSaving: 'Save 16%',
      features: [
        'Unlimited article access',
        'Ad-reduced experience',
        'Enhanced commenting features',
        'Access to basic guides and tutorials',
        'Discounted annual subscription option'
      ]
    },
    {
      id: 'premium',
      name: 'Premium',
      monthlyPrice: '$9.99',
      annualPrice: '$99.99',
      annualSaving: 'Save 16%',
      features: [
        'All Basic tier features',
        'Ad-free experience',
        'Exclusive content access',
        'Early access to new content',
        'Downloadable resources',
        'Priority support',
        'Writer/contributor features'
      ]
    }
  ];

  const handlePlanSelect = (planId) => {
    setSelectedPlan(planId);
    if (planId !== 'free' && planId !== user?.subscription) {
      setShowPaymentForm(true);
    } else {
      setShowPaymentForm(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      // Update user subscription
      updateUserSubscription(selectedPlan);
      setIsProcessing(false);
      setShowPaymentForm(false);
      setSuccessMessage(`Successfully upgraded to ${selectedPlan.charAt(0).toUpperCase() + selectedPlan.slice(1)} plan!`);
      
      // Clear success message after 5 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 5000);
    }, 2000);
  };

  if (!user) {
    return (
      <div className="py-12">
        <div className="container">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-forest-green mb-4">Please Login</h1>
            <p className="text-rock-slate mb-6">You need to be logged in to manage your subscription.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12">
      <div className="container">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl font-bold text-forest-green mb-6">Manage Your Subscription</h1>
          
          {successMessage && (
            <div className="bg-leaf-green bg-opacity-10 border border-leaf-green text-leaf-green p-4 rounded-md mb-6">
              {successMessage}
            </div>
          )}
          
          <div className="bg-white shadow-light rounded-lg overflow-hidden mb-8">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-4">Current Plan</h2>
              <div className="flex items-center mb-6">
                <span className={`inline-block px-3 py-1 rounded-full text-white text-sm mr-2 ${
                  user.subscription === 'premium' 
                    ? 'bg-premium-tier' 
                    : user.subscription === 'basic' 
                      ? 'bg-basic-tier' 
                      : 'bg-free-tier'
                }`}>
                  {user.subscription.charAt(0).toUpperCase() + user.subscription.slice(1)} Plan
                </span>
                {user.subscription !== 'premium' && (
                  <span className="text-rock-slate">
                    Upgrade to get more features
                  </span>
                )}
              </div>
              
              {/* Billing Toggle */}
              <div className="flex mb-6">
                <div className="bg-light-gray inline-flex rounded-lg p-1">
                  <button
                    className={`px-4 py-2 rounded-md ${billingCycle === 'monthly' ? 'bg-white shadow-sm' : ''}`}
                    onClick={() => setBillingCycle('monthly')}
                  >
                    Monthly
                  </button>
                  <button
                    className={`px-4 py-2 rounded-md ${billingCycle === 'annual' ? 'bg-white shadow-sm' : ''}`}
                    onClick={() => setBillingCycle('annual')}
                  >
                    Annual <span className="text-xs text-sunset-orange font-medium">Save 16%</span>
                  </button>
                </div>
              </div>
              
              {/* Subscription Plans */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                {plans.map((plan) => (
                  <div
                    key={plan.id}
                    className={`subscription-card ${plan.id} cursor-pointer ${selectedPlan === plan.id ? 'border-2 border-forest-green' : ''}`}
                    onClick={() => handlePlanSelect(plan.id)}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-xl font-bold">{plan.name}</h3>
                      {selectedPlan === plan.id && (
                        <span className="bg-forest-green text-white p-1 rounded-full">
                          ✓
                        </span>
                      )}
                    </div>
                    
                    <div className="mb-6">
                      <span className="text-2xl font-bold">
                        {billingCycle === 'monthly' ? plan.monthlyPrice : plan.annualPrice}
                      </span>
                      <span className="text-mountain-gray">
                        {billingCycle === 'monthly' ? '/month' : '/year'}
                      </span>
                      {billingCycle === 'annual' && plan.annualSaving && (
                        <div className="mt-2">
                          <span className="text-sm bg-sunset-orange text-white px-2 py-1 rounded-full">
                            {plan.annualSaving}
                          </span>
                        </div>
                      )}
                    </div>
                    
                    <ul className="space-y-2 mb-4">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start text-sm">
                          <span className="text-leaf-green mr-2">✓</span>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
              
              {/* Payment Form */}
              {showPaymentForm && (
                <div className="border-t border-border pt-6">
                  <h3 className="text-xl font-bold mb-4">Payment Information</h3>
                  
                  <div className="mb-4">
                    <div className="flex space-x-4 mb-4">
                      <button
                        className={`flex-1 p-3 border rounded-md flex items-center justify-center ${paymentMethod === 'stripe' ? 'border-forest-green bg-light-gray' : 'border-border'}`}
                        onClick={() => setPaymentMethod('stripe')}
                      >
                        <span className="font-medium">Credit Card</span>
                      </button>
                      <button
                        className={`flex-1 p-3 border rounded-md flex items-center justify-center ${paymentMethod === 'paypal' ? 'border-forest-green bg-light-gray' : 'border-border'}`}
                        onClick={() => setPaymentMethod('paypal')}
                      >
                        <span className="font-medium">PayPal</span>
                      </button>
                    </div>
                  </div>
                  
                  <form onSubmit={handleSubmit}>
                    {paymentMethod === 'stripe' ? (
                      <div className="space-y-4">
                        <div>
                          <label className="block text-rock-slate mb-1">Card Number</label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="1234 5678 9012 3456"
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-rock-slate mb-1">Expiration Date</label>
                            <input
                              type="text"
                              className="form-control"
                              placeholder="MM/YY"
                            />
                          </div>
                          <div>
                            <label className="block text-rock-slate mb-1">CVC</label>
                            <input
                              type="text"
                              className="form-control"
                              placeholder="123"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label className="block text-rock-slate mb-1">Name on Card</label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="John Doe"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="text-center p-6 bg-light-gray rounded-md">
                        <p className="mb-4">You will be redirected to PayPal to complete your payment.</p>
                      </div>
                    )}
                    
                    <div className="mt-6">
                      <button
                        type="submit"
                        className="btn btn-cta w-full"
                        disabled={isProcessing}
                      >
                        {isProcessing ? 'Processing...' : `Subscribe - ${billingCycle === 'monthly' 
                          ? plans.find(p => p.id === selectedPlan).monthlyPrice + '/month' 
                          : plans.find(p => p.id === selectedPlan).annualPrice + '/year'}`}
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
          
          <div className="bg-white shadow-light rounded-lg overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-4">Billing History</h2>
              
              {user.subscription === 'free' ? (
                <p className="text-rock-slate">No billing history available for free plan.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 px-4">Date</th>
                        <th className="text-left py-2 px-4">Description</th>
                        <th className="text-left py-2 px-4">Amount</th>
                        <th className="text-left py-2 px-4">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-border">
                        <td className="py-2 px-4">Apr 15, 2025</td>
                        <td className="py-2 px-4">{user.subscription.charAt(0).toUpperCase() + user.subscription.slice(1)} Plan - Monthly</td>
                        <td className="py-2 px-4">{user.subscription === 'premium' ? '$9.99' : '$5.99'}</td>
                        <td className="py-2 px-4"><span className="text-leaf-green">Paid</span></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionManagement;
