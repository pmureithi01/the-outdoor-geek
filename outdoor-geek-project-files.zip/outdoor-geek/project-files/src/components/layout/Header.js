import React, { useState } from 'react';
import Link from 'next/link';
import { Menu, X, Search, User, ChevronDown } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <header className="bg-white shadow-light sticky top-0 z-50">
      <div className="container">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold text-forest-green">
              The Outdoor Geek
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <div className="relative group">
              <button 
                className="flex items-center text-rock-slate hover:text-forest-green"
                onClick={toggleDropdown}
              >
                Activities <ChevronDown size={16} className="ml-1" />
              </button>
              <div className={`absolute top-full left-0 bg-white shadow-medium rounded-md p-4 w-64 grid grid-cols-1 gap-2 ${isDropdownOpen ? 'block' : 'hidden'}`}>
                <Link href="/activities/land-based" className="hover:text-forest-green">Land-Based Activities</Link>
                <Link href="/activities/water-based" className="hover:text-forest-green">Water-Based Activities</Link>
                <Link href="/activities/air-based" className="hover:text-forest-green">Air-Based Activities</Link>
                <Link href="/activities/other" className="hover:text-forest-green">Other Activities</Link>
              </div>
            </div>
            <Link href="/articles" className="text-rock-slate hover:text-forest-green">
              Articles
            </Link>
            <Link href="/about" className="text-rock-slate hover:text-forest-green">
              About
            </Link>
            <Link href="/contact" className="text-rock-slate hover:text-forest-green">
              Contact
            </Link>
          </nav>

          {/* Search and User Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <button className="text-rock-slate hover:text-forest-green">
              <Search size={20} />
            </button>
            <Link href="/login" className="text-rock-slate hover:text-forest-green">
              <User size={20} />
            </Link>
            <Link href="/subscribe" className="btn btn-primary">
              Subscribe
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-rock-slate" onClick={toggleMenu}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <nav className="flex flex-col space-y-4">
              <button 
                className="flex items-center justify-between text-rock-slate"
                onClick={toggleDropdown}
              >
                Activities <ChevronDown size={16} className={isDropdownOpen ? 'transform rotate-180' : ''} />
              </button>
              {isDropdownOpen && (
                <div className="pl-4 flex flex-col space-y-2">
                  <Link href="/activities/land-based" className="text-rock-slate hover:text-forest-green">
                    Land-Based Activities
                  </Link>
                  <Link href="/activities/water-based" className="text-rock-slate hover:text-forest-green">
                    Water-Based Activities
                  </Link>
                  <Link href="/activities/air-based" className="text-rock-slate hover:text-forest-green">
                    Air-Based Activities
                  </Link>
                  <Link href="/activities/other" className="text-rock-slate hover:text-forest-green">
                    Other Activities
                  </Link>
                </div>
              )}
              <Link href="/articles" className="text-rock-slate hover:text-forest-green">
                Articles
              </Link>
              <Link href="/about" className="text-rock-slate hover:text-forest-green">
                About
              </Link>
              <Link href="/contact" className="text-rock-slate hover:text-forest-green">
                Contact
              </Link>
              <div className="flex items-center space-x-4 pt-2">
                <button className="text-rock-slate hover:text-forest-green">
                  <Search size={20} />
                </button>
                <Link href="/login" className="text-rock-slate hover:text-forest-green">
                  <User size={20} />
                </Link>
              </div>
              <Link href="/subscribe" className="btn btn-primary w-full text-center">
                Subscribe
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
