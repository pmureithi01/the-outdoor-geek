import React from 'react';
import Link from 'next/link';
import { Facebook, Twitter, Instagram, Youtube, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-forest-green text-white py-12">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and About */}
          <div className="col-span-1">
            <Link href="/" className="text-2xl font-bold">
              The Outdoor Geek
            </Link>
            <p className="mt-4">
              Your ultimate resource for outdoor activities, adventures, and gear reviews.
            </p>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-white hover:text-sunrise-yellow">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white hover:text-sunrise-yellow">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-white hover:text-sunrise-yellow">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white hover:text-sunrise-yellow">
                <Youtube size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="col-span-1">
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-white hover:text-sunrise-yellow">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-white hover:text-sunrise-yellow">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/subscribe" className="text-white hover:text-sunrise-yellow">
                  Subscribe
                </Link>
              </li>
              <li>
                <Link href="/writers" className="text-white hover:text-sunrise-yellow">
                  Become a Writer
                </Link>
              </li>
              <li>
                <Link href="/advertise" className="text-white hover:text-sunrise-yellow">
                  Advertise with Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Activity Categories */}
          <div className="col-span-1">
            <h3 className="text-xl font-semibold mb-4">Activities</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/activities/land-based" className="text-white hover:text-sunrise-yellow">
                  Land-Based Activities
                </Link>
              </li>
              <li>
                <Link href="/activities/water-based" className="text-white hover:text-sunrise-yellow">
                  Water-Based Activities
                </Link>
              </li>
              <li>
                <Link href="/activities/air-based" className="text-white hover:text-sunrise-yellow">
                  Air-Based Activities
                </Link>
              </li>
              <li>
                <Link href="/activities/other" className="text-white hover:text-sunrise-yellow">
                  Other Activities
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div className="col-span-1">
            <h3 className="text-xl font-semibold mb-4">Newsletter</h3>
            <p className="mb-4">Subscribe to our newsletter for the latest outdoor tips and adventures.</p>
            <form className="flex flex-col space-y-2">
              <input
                type="email"
                placeholder="Your email address"
                className="px-4 py-2 rounded-md text-rock-slate"
              />
              <button type="submit" className="bg-sunset-orange hover:bg-opacity-90 text-white py-2 rounded-md">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="border-t border-white border-opacity-20 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {new Date().getFullYear()} The Outdoor Geek. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Link href="/terms" className="text-white hover:text-sunrise-yellow">
              Terms of Service
            </Link>
            <Link href="/privacy" className="text-white hover:text-sunrise-yellow">
              Privacy Policy
            </Link>
            <Link href="/cookies" className="text-white hover:text-sunrise-yellow">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
