import React, { useState } from 'react';
import { useAuth } from '../../lib/auth';

const UserProfilePage = () => {
  const { user, logout, updateUserSubscription } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [successMessage, setSuccessMessage] = useState('');

  const handleSaveProfile = () => {
    // In a real implementation, this would call an API to update the user profile
    // For now, we'll just simulate a successful update
    setTimeout(() => {
      setSuccessMessage('Profile updated successfully!');
      setIsEditing(false);
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    }, 500);
  };

  if (!user) {
    return (
      <div className="py-12">
        <div className="container">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-forest-green mb-4">Please Login</h1>
            <p className="text-rock-slate mb-6">You need to be logged in to view your profile.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12">
      <div className="container">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-forest-green mb-6">Your Profile</h1>
          
          {successMessage && (
            <div className="bg-leaf-green bg-opacity-10 border border-leaf-green text-leaf-green p-4 rounded-md mb-6">
              {successMessage}
            </div>
          )}
          
          <div className="bg-white shadow-light rounded-lg overflow-hidden mb-8">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                  <div className="w-16 h-16 bg-forest-green text-white rounded-full flex items-center justify-center text-2xl font-bold mr-4">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold">{user.name}</h2>
                    <p className="text-mountain-gray">{user.email}</p>
                  </div>
                </div>
                <div>
                  <button 
                    onClick={() => setIsEditing(!isEditing)} 
                    className="btn btn-secondary"
                  >
                    {isEditing ? 'Cancel' : 'Edit Profile'}
                  </button>
                </div>
              </div>
              
              {isEditing ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-rock-slate mb-1">Name</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="form-control"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-rock-slate mb-1">Bio</label>
                    <textarea
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      className="form-control"
                      rows="4"
                    ></textarea>
                  </div>
                  
                  <button 
                    onClick={handleSaveProfile} 
                    className="btn btn-primary"
                  >
                    Save Changes
                  </button>
                </div>
              ) : (
                <div>
                  <h3 className="text-lg font-semibold mb-2">About</h3>
                  <p className="text-rock-slate mb-4">
                    {user.bio || 'No bio provided yet. Click "Edit Profile" to add your bio.'}
                  </p>
                  
                  <h3 className="text-lg font-semibold mb-2">Membership</h3>
                  <div className="flex items-center">
                    <span className={`inline-block px-3 py-1 rounded-full text-white text-sm mr-2 ${
                      user.subscription === 'premium' 
                        ? 'bg-premium-tier' 
                        : user.subscription === 'basic' 
                          ? 'bg-basic-tier' 
                          : 'bg-free-tier'
                    }`}>
                      {user.subscription.charAt(0).toUpperCase() + user.subscription.slice(1)} Plan
                    </span>
                    <a href="/subscribe" className="text-forest-green hover:underline">
                      Upgrade
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="bg-white shadow-light rounded-lg overflow-hidden mb-8">
            <div className="p-6">
              <h3 className="text-xl font-bold mb-4">Account Settings</h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Email Notifications</h4>
                  <div className="flex items-center">
                    <input type="checkbox" id="newsletter" className="mr-2" defaultChecked />
                    <label htmlFor="newsletter">Receive newsletter</label>
                  </div>
                  <div className="flex items-center mt-2">
                    <input type="checkbox" id="comments" className="mr-2" defaultChecked />
                    <label htmlFor="comments">Notify me of replies to my comments</label>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Password</h4>
                  <button className="text-forest-green hover:underline">
                    Change Password
                  </button>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Danger Zone</h4>
                  <button 
                    onClick={logout} 
                    className="text-alert-red hover:underline"
                  >
                    Logout
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          {(user.role === 'writer' || user.role === 'admin') && (
            <div className="bg-white shadow-light rounded-lg overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-4">Writer Dashboard</h3>
                <p className="mb-4">Manage your articles and track performance.</p>
                <a href="/writer/dashboard" className="btn btn-primary">
                  Go to Writer Dashboard
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserProfilePage;
