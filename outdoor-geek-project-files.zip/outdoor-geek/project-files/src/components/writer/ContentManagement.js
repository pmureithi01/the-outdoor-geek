import React, { useState } from 'react';
import { useAuth } from '../../lib/auth';

const ContentManagement = () => {
  const { user, isWriter } = useAuth();
  const [articles, setArticles] = useState([
    {
      id: '1',
      title: 'Essential Gear for Hiking in All Seasons',
      excerpt: 'Discover the must-have equipment for hiking year-round, from summer heat to winter snow.',
      category: 'Hiking',
      status: 'published',
      date: 'Apr 10, 2025',
      views: 1245
    },
    {
      id: '2',
      title: 'Beginner\'s Guide to Rock Climbing',
      excerpt: 'Everything you need to know to get started with rock climbing safely and confidently.',
      category: 'Rock Climbing',
      status: 'draft',
      date: 'Apr 15, 2025',
      views: 0
    }
  ]);
  
  const [activeTab, setActiveTab] = useState('published');
  
  if (!user || !isWriter) {
    return (
      <div className="py-12">
        <div className="container">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-forest-green mb-4">Writer Access Only</h1>
            <p className="text-rock-slate mb-6">You need to be logged in as a writer to access content management.</p>
          </div>
        </div>
      </div>
    );
  }
  
  const filteredArticles = articles.filter(article => 
    activeTab === 'all' || article.status === activeTab
  );
  
  return (
    <div className="py-12">
      <div className="container">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-forest-green">Content Management</h1>
            <a href="/writer/new-article" className="btn btn-primary">
              Create New Article
            </a>
          </div>
          
          {/* Tabs */}
          <div className="border-b border-border mb-6">
            <div className="flex space-x-6">
              <button 
                className={`pb-3 px-1 ${activeTab === 'all' ? 'border-b-2 border-forest-green text-forest-green font-semibold' : 'text-rock-slate'}`}
                onClick={() => setActiveTab('all')}
              >
                All
              </button>
              <button 
                className={`pb-3 px-1 ${activeTab === 'published' ? 'border-b-2 border-forest-green text-forest-green font-semibold' : 'text-rock-slate'}`}
                onClick={() => setActiveTab('published')}
              >
                Published
              </button>
              <button 
                className={`pb-3 px-1 ${activeTab === 'draft' ? 'border-b-2 border-forest-green text-forest-green font-semibold' : 'text-rock-slate'}`}
                onClick={() => setActiveTab('draft')}
              >
                Drafts
              </button>
            </div>
          </div>
          
          {/* Articles Table */}
          <div className="bg-white shadow-light rounded-lg overflow-hidden mb-8">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-light-gray">
                    <th className="text-left py-3 px-4 font-semibold">Title</th>
                    <th className="text-left py-3 px-4 font-semibold">Category</th>
                    <th className="text-left py-3 px-4 font-semibold">Status</th>
                    <th className="text-left py-3 px-4 font-semibold">Date</th>
                    <th className="text-left py-3 px-4 font-semibold">Views</th>
                    <th className="text-left py-3 px-4 font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredArticles.length > 0 ? (
                    filteredArticles.map((article) => (
                      <tr key={article.id} className="border-t border-border">
                        <td className="py-3 px-4">
                          <div>
                            <p className="font-medium">{article.title}</p>
                            <p className="text-sm text-mountain-gray truncate max-w-xs">{article.excerpt}</p>
                          </div>
                        </td>
                        <td className="py-3 px-4">{article.category}</td>
                        <td className="py-3 px-4">
                          <span className={`inline-block px-2 py-1 rounded-full text-xs ${
                            article.status === 'published' 
                              ? 'bg-leaf-green bg-opacity-10 text-leaf-green' 
                              : 'bg-mountain-gray bg-opacity-10 text-mountain-gray'
                          }`}>
                            {article.status.charAt(0).toUpperCase() + article.status.slice(1)}
                          </span>
                        </td>
                        <td className="py-3 px-4">{article.date}</td>
                        <td className="py-3 px-4">{article.views}</td>
                        <td className="py-3 px-4">
                          <div className="flex space-x-2">
                            <a 
                              href={`/writer/edit/${article.id}`} 
                              className="text-forest-green hover:underline"
                            >
                              Edit
                            </a>
                            <button className="text-alert-red hover:underline">
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="6" className="py-4 px-4 text-center text-mountain-gray">
                        No articles found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
          
          {/* Analytics Summary */}
          <div className="bg-white shadow-light rounded-lg overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-6">Performance Overview</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="bg-light-gray p-4 rounded-lg">
                  <p className="text-mountain-gray mb-1">Total Views</p>
                  <p className="text-3xl font-bold">1,245</p>
                </div>
                
                <div className="bg-light-gray p-4 rounded-lg">
                  <p className="text-mountain-gray mb-1">Total Comments</p>
                  <p className="text-3xl font-bold">32</p>
                </div>
                
                <div className="bg-light-gray p-4 rounded-lg">
                  <p className="text-mountain-gray mb-1">Affiliate Clicks</p>
                  <p className="text-3xl font-bold">87</p>
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">Top Performing Article</h3>
                <div className="flex items-center">
                  <div className="flex-grow">
                    <p className="font-medium">Essential Gear for Hiking in All Seasons</p>
                    <p className="text-sm text-mountain-gray">1,245 views • 24 comments</p>
                  </div>
                  <a href="/analytics" className="text-forest-green hover:underline">
                    View Details
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContentManagement;
