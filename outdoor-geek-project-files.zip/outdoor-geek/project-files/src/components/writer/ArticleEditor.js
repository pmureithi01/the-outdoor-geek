import React, { useState } from 'react';
import { useAuth } from '../../lib/auth';

const ArticleEditor = ({ article = null, isEditing = false }) => {
  const { user, isWriter } = useAuth();
  const [title, setTitle] = useState(article?.title || '');
  const [content, setContent] = useState(article?.content || '');
  const [excerpt, setExcerpt] = useState(article?.excerpt || '');
  const [category, setCategory] = useState(article?.category || 'Hiking');
  const [tags, setTags] = useState(article?.tags?.join(', ') || '');
  const [featuredImage, setFeaturedImage] = useState(null);
  const [status, setStatus] = useState(article?.status || 'draft');
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  const categories = [
    'Hiking', 'Camping', 'Rock Climbing', 'Mountaineering', 'Kayaking', 
    'Fishing', 'Paragliding', 'Birdwatching', 'Photography'
  ];
  
  if (!user || !isWriter) {
    return (
      <div className="py-12">
        <div className="container">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-forest-green mb-4">Writer Access Only</h1>
            <p className="text-rock-slate mb-6">You need to be logged in as a writer to access the article editor.</p>
          </div>
        </div>
      </div>
    );
  }
  
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      // In a real implementation, this would upload the file to a server
      // For now, we'll just store it locally
      setFeaturedImage(file);
    }
  };
  
  const handleSaveDraft = () => {
    setStatus('draft');
    handleSave();
  };
  
  const handlePublish = () => {
    setStatus('published');
    handleSave();
  };
  
  const handleSave = () => {
    setIsSaving(true);
    
    // Simulate API call to save article
    setTimeout(() => {
      setIsSaving(false);
      setSuccessMessage(status === 'published' ? 'Article published successfully!' : 'Draft saved successfully!');
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    }, 1000);
  };
  
  return (
    <div className="py-12">
      <div className="container">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-forest-green">
              {isEditing ? 'Edit Article' : 'Create New Article'}
            </h1>
            <div className="flex space-x-3">
              <button 
                onClick={handleSaveDraft} 
                className="btn btn-secondary"
                disabled={isSaving}
              >
                {isSaving && status === 'draft' ? 'Saving...' : 'Save Draft'}
              </button>
              <button 
                onClick={handlePublish} 
                className="btn btn-primary"
                disabled={isSaving}
              >
                {isSaving && status === 'published' ? 'Publishing...' : 'Publish'}
              </button>
            </div>
          </div>
          
          {successMessage && (
            <div className="bg-leaf-green bg-opacity-10 border border-leaf-green text-leaf-green p-4 rounded-md mb-6">
              {successMessage}
            </div>
          )}
          
          <div className="bg-white shadow-light rounded-lg overflow-hidden mb-8">
            <div className="p-6">
              <div className="mb-6">
                <label htmlFor="title" className="block text-rock-slate mb-2 font-medium">
                  Article Title
                </label>
                <input
                  id="title"
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="form-control text-xl"
                  placeholder="Enter article title"
                  required
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="excerpt" className="block text-rock-slate mb-2 font-medium">
                  Excerpt
                </label>
                <textarea
                  id="excerpt"
                  value={excerpt}
                  onChange={(e) => setExcerpt(e.target.value)}
                  className="form-control"
                  rows="2"
                  placeholder="Brief summary of the article"
                  required
                ></textarea>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="category" className="block text-rock-slate mb-2 font-medium">
                    Category
                  </label>
                  <select
                    id="category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="form-control"
                    required
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label htmlFor="tags" className="block text-rock-slate mb-2 font-medium">
                    Tags
                  </label>
                  <input
                    id="tags"
                    type="text"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    className="form-control"
                    placeholder="Enter tags separated by commas"
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <label className="block text-rock-slate mb-2 font-medium">
                  Featured Image
                </label>
                <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
                  {featuredImage ? (
                    <div>
                      <p className="mb-2">{featuredImage.name}</p>
                      <button 
                        onClick={() => setFeaturedImage(null)}
                        className="text-alert-red hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div>
                      <p className="text-mountain-gray mb-2">Drag and drop an image here, or click to select a file</p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                        id="featured-image"
                      />
                      <label htmlFor="featured-image" className="btn btn-secondary inline-block cursor-pointer">
                        Select Image
                      </label>
                    </div>
                  )}
                </div>
              </div>
              
              <div>
                <label htmlFor="content" className="block text-rock-slate mb-2 font-medium">
                  Article Content
                </label>
                <textarea
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="form-control"
                  rows="15"
                  placeholder="Write your article content here..."
                  required
                ></textarea>
              </div>
            </div>
          </div>
          
          <div className="bg-white shadow-light rounded-lg overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-4">Affiliate Links</h2>
              <p className="text-rock-slate mb-4">
                As a writer, you can include affiliate links in your content. Please ensure all affiliate links are clearly disclosed to readers.
              </p>
              
              <div className="mb-4">
                <label htmlFor="affiliate-disclosure" className="block text-rock-slate mb-2 font-medium">
                  Affiliate Disclosure
                </label>
                <textarea
                  id="affiliate-disclosure"
                  className="form-control"
                  rows="2"
                  defaultValue="This article contains affiliate links. As an Amazon Associate I earn from qualifying purchases."
                ></textarea>
              </div>
              
              <div className="border-t border-border pt-4">
                <h3 className="font-semibold mb-2">Tips for Using Affiliate Links</h3>
                <ul className="list-disc pl-5 space-y-1 text-rock-slate">
                  <li>Always disclose affiliate relationships to your readers</li>
                  <li>Only recommend products you genuinely believe in</li>
                  <li>Provide honest reviews and opinions</li>
                  <li>Focus on providing value to readers first</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticleEditor;
