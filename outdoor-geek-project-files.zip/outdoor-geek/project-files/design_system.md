# The Outdoor Geek - Design System

## Color Palette

### Primary Colors
- **Forest Green** (#2E5A35): Primary brand color representing forests and vegetation
- **Sky Blue** (#4A90E2): Representing clear skies and water bodies
- **Earth Brown** (#8B572A): Representing soil, mountains, and trails

### Secondary Colors
- **Sunset Orange** (#F5A623): For accents, calls-to-action, and highlights
- **Mountain Gray** (#9B9B9B): For neutral backgrounds and text
- **Rock Slate** (#4A4A4A): For darker text and elements

### Tertiary Colors
- **Leaf Green** (#7ED321): For success states and nature elements
- **Water Blue** (#50E3C2): For water-related categories and elements
- **Sunrise Yellow** (#F8E71C): For air-related categories and highlights
- **Alert Red** (#D0021B): For error states and important notifications

### Subscription Tier Colors
- **Free Tier** (#9B9B9B): Gray for basic tier
- **Basic Tier** (#4A90E2): Blue for intermediate tier
- **Premium Tier** (#F5A623): Orange/Gold for premium tier

## Typography

### Headings
- **Font Family**: Montserrat (Sans-serif)
- **Weights**: Bold (700) for main headings, Semi-bold (600) for subheadings
- **Sizes**:
  - H1: 2.5rem (40px)
  - H2: 2rem (32px)
  - H3: 1.5rem (24px)
  - H4: 1.25rem (20px)
  - H5: 1.125rem (18px)
  - H6: 1rem (16px)

### Body Text
- **Font Family**: Open Sans (Sans-serif)
- **Weights**: Regular (400), Medium (500), Bold (700)
- **Sizes**:
  - Body Large: 1.125rem (18px)
  - Body Regular: 1rem (16px)
  - Body Small: 0.875rem (14px)
  - Caption: 0.75rem (12px)

### Special Text
- **Font Family**: Roboto Mono (Monospace) for code snippets or technical content
- **Weight**: Regular (400)
- **Size**: 0.875rem (14px)

## Spacing System

### Base Unit
- 4px as the base unit for all spacing

### Spacing Scale
- **xs**: 4px (0.25rem)
- **sm**: 8px (0.5rem)
- **md**: 16px (1rem)
- **lg**: 24px (1.5rem)
- **xl**: 32px (2rem)
- **2xl**: 48px (3rem)
- **3xl**: 64px (4rem)
- **4xl**: 96px (6rem)

## Border Radius
- **Small**: 4px
- **Medium**: 8px
- **Large**: 12px
- **Round**: 50% (for circular elements)

## Shadows
- **Light**: 0 2px 4px rgba(0, 0, 0, 0.1)
- **Medium**: 0 4px 8px rgba(0, 0, 0, 0.1)
- **Heavy**: 0 8px 16px rgba(0, 0, 0, 0.1)

## Icons
- Use Lucide icons for consistency
- Icon sizes:
  - Small: 16px
  - Medium: 24px
  - Large: 32px

## Components

### Buttons

#### Primary Button
- Background: Forest Green (#2E5A35)
- Text: White (#FFFFFF)
- Hover: Darker shade of Forest Green
- Border Radius: Medium (8px)
- Padding: 12px 24px

#### Secondary Button
- Background: White (#FFFFFF)
- Text: Forest Green (#2E5A35)
- Border: 1px solid Forest Green (#2E5A35)
- Hover: Light green background
- Border Radius: Medium (8px)
- Padding: 12px 24px

#### Tertiary Button
- Background: Transparent
- Text: Forest Green (#2E5A35)
- Hover: Light green background
- Border Radius: Medium (8px)
- Padding: 12px 24px

#### CTA Button
- Background: Sunset Orange (#F5A623)
- Text: White (#FFFFFF)
- Hover: Darker shade of Sunset Orange
- Border Radius: Medium (8px)
- Padding: 12px 24px

### Cards

#### Content Card
- Background: White (#FFFFFF)
- Border: 1px solid #EEEEEE
- Border Radius: Medium (8px)
- Shadow: Light
- Padding: 24px

#### Category Card
- Background: White (#FFFFFF)
- Border: 1px solid #EEEEEE
- Border Radius: Medium (8px)
- Shadow: Light
- Padding: 16px
- Image: Top portion of card
- Title: Below image

#### Subscription Card
- Background: White (#FFFFFF)
- Border: 1px solid #EEEEEE
- Border Radius: Medium (8px)
- Shadow: Medium
- Padding: 24px
- Highlight: Top border with tier color

### Navigation

#### Main Navigation
- Background: White (#FFFFFF)
- Text: Rock Slate (#4A4A4A)
- Active: Forest Green (#2E5A35)
- Hover: Light green background
- Shadow: Light

#### Mobile Navigation
- Background: White (#FFFFFF)
- Text: Rock Slate (#4A4A4A)
- Active: Forest Green (#2E5A35)
- Hamburger Icon: Rock Slate (#4A4A4A)

### Forms

#### Input Fields
- Border: 1px solid #EEEEEE
- Border Radius: Medium (8px)
- Focus: Border color changes to Forest Green (#2E5A35)
- Padding: 12px 16px
- Background: White (#FFFFFF)

#### Checkboxes and Radio Buttons
- Unchecked: White background with gray border
- Checked: Forest Green (#2E5A35) background
- Size: 20px x 20px

#### Dropdown
- Border: 1px solid #EEEEEE
- Border Radius: Medium (8px)
- Arrow: Rock Slate (#4A4A4A)
- Padding: 12px 16px
- Background: White (#FFFFFF)

### Banners

#### Ad Banners
- Border: 1px solid #EEEEEE
- Border Radius: Medium (8px)
- Background: Light gray (#F8F8F8)
- Label: "Advertisement" in small caption text

#### Notification Banners
- Success: Light green background with Leaf Green (#7ED321) border
- Error: Light red background with Alert Red (#D0021B) border
- Info: Light blue background with Sky Blue (#4A90E2) border
- Border Radius: Medium (8px)
- Padding: 16px

## Responsive Breakpoints

- **Mobile**: < 640px
- **Tablet**: 640px - 1023px
- **Desktop**: 1024px - 1279px
- **Large Desktop**: >= 1280px

## Accessibility

- All text should maintain a minimum contrast ratio of 4.5:1 against its background
- Interactive elements should have a visible focus state
- Font sizes should not go below 12px for readability
- All interactive elements should be accessible via keyboard navigation
