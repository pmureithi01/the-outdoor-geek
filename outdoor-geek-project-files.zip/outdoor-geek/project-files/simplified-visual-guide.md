# Visual Guide: Deploying "The Outdoor Geek" to Vercel

This step-by-step visual guide will walk you through the process of deploying your website to Vercel and connecting it to your custom domain.

## Step 1: Create a Vercel Account

1. Go to [vercel.com](https://vercel.com) and click "Sign Up"
2. You can sign up with GitHub, GitLab, Bitbucket, or email
3. Complete the registration process

![Vercel Login Page](/home/ubuntu/outdoor-geek/images/vercel_login.png)

## Step 2: Create a New Project

1. From your Vercel dashboard, click "Add New..." → "Project"

![Vercel Homepage](/home/ubuntu/outdoor-geek/images/vercel_homepage.png)

2. You'll see options to import from Git repositories or use templates

![New Project Page](/home/ubuntu/outdoor-geek/images/vercel_new_project.png)

3. For simplicity, we'll use the "Import Third-Party Git Repository" option

![Import Repository](/home/ubuntu/outdoor-geek/images/vercel_import_repo.png)

## Step 3: Upload Your Project Files

1. Download the project files from the link I'll provide separately
2. Create a GitHub repository and upload the files
3. Enter your repository URL in the field provided by Vercel
4. Click "Continue"

## Step 4: Configure Project Settings

1. Give your project a name (e.g., "the-outdoor-geek")
2. Make sure the Framework Preset is set to "Next.js"
3. Leave other settings at their defaults
4. Click "Deploy"

## Step 5: Wait for Deployment

1. Vercel will now build and deploy your website
2. This process typically takes 1-2 minutes
3. You'll see a progress indicator during deployment

## Step 6: Success! Your Site is Deployed

1. Once deployment is complete, you'll see a success message
2. Your site is now live at a temporary Vercel URL (e.g., the-outdoor-geek.vercel.app)
3. Click "Continue to Dashboard"

## Step 7: Add Your Custom Domain

1. From your project dashboard, click on "Settings" → "Domains"
2. Enter your domain name: www.theoutdoorgeek.com
3. Click "Add"

![Domain Configuration](/home/ubuntu/outdoor-geek/images/vercel_domain_config.png)

## Step 8: Configure DNS Settings

1. Vercel will show you the required DNS records to add
2. You'll need to add these records at your domain registrar (GoDaddy, Namecheap, etc.)
3. Typically, you'll need to add:
   - For the apex domain (theoutdoorgeek.com): an A record pointing to Vercel's IP
   - For the www subdomain: a CNAME record pointing to Vercel

## Step 9: Verify Domain Connection

1. Back in Vercel, wait for the domain verification to complete
2. This may take 5-60 minutes depending on DNS propagation
3. Once verified, you'll see a green checkmark next to your domain

## Step 10: Visit Your Live Website!

1. Your website is now live at www.theoutdoorgeek.com
2. Vercel automatically handles SSL certificates for secure HTTPS
3. Your site is now deployed on a global CDN for fast loading worldwide

## Updating Your Website in the Future

When you want to make updates to your website:

1. Make your changes to the project files in your GitHub repository
2. Commit and push the changes
3. Vercel will automatically detect the changes and deploy the updates

That's it! Your website is now live and ready for visitors.
